package fr.uga.iut2.genevent.modele;

import java.io.Serializable;

public class Hotel implements Serializable {
    private String nom;
    private double prixPersonne;

    /**
     * Constructeur Hotel avec comme paramètre le nom et le prix par personne de l'hotel
     * @param nom le nom de l'hotel
     * @param prixPersonne le prix par personne de l'hotel
     */
    public Hotel(String nom, double prixPersonne) {
        setNom(nom);
        setPrixPersonne(prixPersonne);
    }

    /**
     * Permet d'acceder au nom de l'hotel
     * @return le nom de l'hotel
     */
    public String getNom() {
        return nom;
    }

    /**
     * Permet d'attribuer un nom à l'hotel
     * @param nom le nom de l'hotel
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Permet d'acceder au prix par personne de l'hotel
     * @return le prix par personne pour l'hotel
     */
    public double getPrixPersonne() {
        return prixPersonne;
    }

    /**
     * Permet d'attribuer le prix par personne pour un hotel
     * @param prixPersonne le prix par personne pour l'hotel
     */
    public void setPrixPersonne(double prixPersonne) {
        this.prixPersonne = prixPersonne;
    }


}
