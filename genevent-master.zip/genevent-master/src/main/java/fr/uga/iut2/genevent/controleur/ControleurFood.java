package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

public class ControleurFood {

    //Attributs
    private GenEvent genEvent;
    private Evenement evenement;
    private Seminaire seminaire;
    public static final Logger LOGGER = Logger.getLogger(ControleurFood.class.getName());
    @FXML private TextField quant1, quant2, quant3, quant4;
    @FXML private Text nom1, nom2, nom3, nom4, prix1, prix2, prix3, prix4;

    //Constructeurs
    public ControleurFood(GenEvent genEvent, Evenement event) {
        this.genEvent = genEvent;
        this.evenement = event;
    }

    public ControleurFood(GenEvent genEvent, Seminaire seminaire) {
        this.genEvent = genEvent;
        this.seminaire = seminaire;
    }

    // ------------ Création des menus ------------
    // ------------ Menu n°1 (Pot de Départs, Soirée d'intégration, Soirée afterwork, team-building) ------------
    Nourriture pizza = new Nourriture("Pizza (vegetarian option)", 10.00, 0, false, true, false);
    Nourriture burger = new Nourriture("Cheeseburger (vegetarian option)", 7.50, 0, false, true, false);
    Nourriture glace = new Nourriture("Ice Cream", 2.50, 0, false, true, true);
    Nourriture biere = new Nourriture("Bier (pack of 6)", 4.50, 0, true, true, true);
    Nourriture soda = new Nourriture("Soda",1.00, 0, true, true, false);
    // ------------ Menu n°2 (Conférences) ------------
    Nourriture petitFour = new Nourriture("Appetizer", 10.00, 0, true, true, false);
    Nourriture verrinesSucree = new Nourriture("Sweet starter (by 6)", 8.50,0, false, true, false);
    Nourriture aperitif = new Nourriture("Crisps", 5.00, 0, true, true, false);
    Nourriture cafe = new Nourriture("Coffee (1L)",5.00, 0, true, true, false);
    // ------------ Menu n°3 (Seminaires) ------------
    Nourriture repas = new Nourriture("Meal", 7.00, 0, true, true, false);
    Nourriture repasVege = new Nourriture("Vegetarian meal", 7.00, 0, true, true, false);
    Nourriture repasVegan = new Nourriture("Vegan meal", 7.00, 0, true, true, false);
    Nourriture petitDejeuner = new Nourriture("Breakfast", 2.50, 0, false, true, false);

    //Méthodes

    /**
     * Initialise la page de choix de la nourriture
     * Affiche les menus selon le type d'évènement
     * Permet de choisir la quantité d'un plat
     */
    public void initializeFood() {
        //Sélection des menus selon le type
        if (evenement != null && evenement.getType() == TypeEvenement.CONFERENCE) {
            nom1.setText(petitFour.getNom());
            prix1.setText("Price : " + String.valueOf(petitFour.getPrixUnite()) + "$");
            nom2.setText(verrinesSucree.getNom());
            prix2.setText("Price : " + String.valueOf(verrinesSucree.getPrixUnite()) + "$");
            nom3.setText(aperitif.getNom());
            prix3.setText("Price : " + String.valueOf(aperitif.getPrixUnite()) + "$");
            nom4.setText(cafe.getNom());
            prix4.setText("Price : " + String.valueOf(cafe.getPrixUnite()) + "$");
        } else if (seminaire != null) {
            nom1.setText(repas.getNom());
            prix1.setText("Price : " + String.valueOf(repas.getPrixUnite()) + "$");
            nom2.setText(repasVege.getNom());
            prix2.setText("Price : " + String.valueOf(repasVege.getPrixUnite()) + "$");
            nom3.setText(repasVegan.getNom());
            prix3.setText("Price : " + String.valueOf(repasVegan.getPrixUnite()) + "$");
            nom4.setText(petitDejeuner.getNom());
            prix4.setText("Price : " + String.valueOf(petitDejeuner.getPrixUnite()) + "$");
        } else if (evenement != null) {
            nom1.setText(pizza.getNom());
            prix1.setText("Price : " + String.valueOf(pizza.getPrixUnite()) + "$");
            nom2.setText(burger.getNom());
            prix2.setText("Price : " + String.valueOf(burger.getPrixUnite()) + "$");
            nom3.setText(glace.getNom());
            prix3.setText("Price : " + String.valueOf(glace.getPrixUnite()) + "$");
            if (evenement.getType() == TypeEvenement.TEAMBUILDING) {
                nom4.setText(soda.getNom());
                prix4.setText("Price : " + String.valueOf(soda.getPrixUnite()) + "$");
            } else {
                nom4.setText(biere.getNom());
                prix4.setText("Price : " + String.valueOf(biere.getPrixUnite()) + "$");
            }
        }
        //Ajout des données de l'événement
        ArrayList<Nourriture> menu = new ArrayList<>();
        if (evenement != null) {
            menu = evenement.getMenu();
        } else if (seminaire != null) {
            menu = seminaire.getMenu();
        }
        for (Nourriture nourriture : menu) {
            if (nourriture.getNom().compareTo(nom1.getText()) == 0) {
                quant1.setText(Integer.toString(nourriture.getQuantite()));
            } else if (nourriture.getNom().compareTo(nom2.getText()) == 0) {
                quant2.setText(Integer.toString(nourriture.getQuantite()));
            } else if (nourriture.getNom().compareTo(nom3.getText()) == 0) {
                quant3.setText(Integer.toString(nourriture.getQuantite()));
            } else if (nourriture.getNom().compareTo(nom4.getText()) == 0) {
                quant4.setText(Integer.toString(nourriture.getQuantite()));
            }
        }
    }

    /**
     * Ajoute la quantité des plats voulus au menu de l'évènement, si le budget le permet
     *
     * @param event clic sur le bouton 'Apply' de la page des menus
     */
    @FXML
    private void addFood(ActionEvent event) throws IOException, ExceptionInterface {
        //Suppressions des éléments déjà compris dans le menu de l'évènement pour ne pas les recompter
        boolean erreurEntree = false;
        if (evenement != null) {
            evenement.getMenu().clear();
            LOGGER.info("ajout d'un menu pour l'évènement de nom: "+evenement.getNom());
        } else if (seminaire != null) {
            seminaire.getMenu().clear();
            LOGGER.info("ajout d'un menu pour l'évènement de nom: "+seminaire.getNom());
        }
        //Ajout de la nourriture pour le type conférence
        if (evenement != null && evenement.getType() == TypeEvenement.CONFERENCE) {
            if (!quant1.getText().isEmpty() & isInt(quant1.getText())) {
                evenement.addNourriture(new Nourriture(petitFour.getNom(), petitFour.getPrixUnite(),Integer.parseInt(quant1.getText()), true, true, false));
            } else if (!isInt(quant1.getText()) & !quant1.getText().isEmpty()) {
                quant1.setStyle("-fx-border-color: red");
                quant1.clear();
                quant1.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant1.setStyle("-fx-border-color: black");
                quant1.setPromptText("Quantity");
            }
            if (!quant2.getText().isEmpty() & isInt(quant2.getText())) {
                evenement.addNourriture(new Nourriture(verrinesSucree.getNom(), verrinesSucree.getPrixUnite(),Integer.parseInt(quant2.getText()), false, true, false));
            } else if (!isInt(quant2.getText()) & !quant2.getText().isEmpty()) {
                quant2.setStyle("-fx-border-color: red");
                quant2.clear();
                quant2.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant2.setStyle("-fx-border-color: black");
                quant2.setPromptText("Quantity");
            }
            if (!quant3.getText().isEmpty() & isInt(quant3.getText())) {
                evenement.addNourriture(new Nourriture(aperitif.getNom(), aperitif.getPrixUnite(),Integer.parseInt(quant3.getText()), true, true, false));
            } else if (!isInt(quant3.getText()) & !quant3.getText().isEmpty()) {
                quant3.setStyle("-fx-border-color: red");
                quant3.clear();
                quant3.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant3.setStyle("-fx-border-color: black");
                quant3.setPromptText("Quantity");
            }
            if (!quant4.getText().isEmpty() & isInt(quant4.getText())) {
                evenement.addNourriture(new Nourriture(cafe.getNom(), cafe.getPrixUnite(),Integer.parseInt(quant4.getText()), true, true, false));
            } else if (!isInt(quant4.getText()) & !quant4.getText().isEmpty()) {
                quant4.setStyle("-fx-border-color: red");
                quant4.clear();
                quant4.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant4.setStyle("-fx-border-color: black");
                quant4.setPromptText("Quantity");
            }
        }
        //Ajout de la nourriture pour un séminaire
        else if (seminaire != null) {
            LOGGER.info("ajout d'un menu pour l'évènement de nom: "+seminaire.getNom());
            if (!quant1.getText().isEmpty() & isInt(quant1.getText())) {
                seminaire.addNourriture(new Nourriture(repas.getNom(), repas.getPrixUnite(),Integer.parseInt(quant1.getText()), false, false, false));
            } else if (!isInt(quant1.getText()) & !quant1.getText().isEmpty()) {
                quant1.setStyle("-fx-border-color: red");
                quant1.clear();
                quant1.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant1.setStyle("-fx-border-color: black");
                quant1.setPromptText("Quantity");
            }
            if (!quant2.getText().isEmpty() & isInt(quant2.getText())) {
                seminaire.addNourriture(new Nourriture(repasVege.getNom(), repasVege.getPrixUnite(),Integer.parseInt(quant2.getText()), false, true, false));
            } else if (!isInt(quant2.getText()) & !quant2.getText().isEmpty()) {
                quant2.setStyle("-fx-border-color: red");
                quant2.clear();
                quant2.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant2.setStyle("-fx-border-color: black");
                quant2.setPromptText("Quantity");
            }
            if (!quant3.getText().isEmpty() & isInt(quant3.getText())) {
                seminaire.addNourriture(new Nourriture(repasVegan.getNom(), repasVegan.getPrixUnite(),Integer.parseInt(quant3.getText()), true, true, false));
            } else if (!isInt(quant3.getText()) & !quant3.getText().isEmpty()) {
                quant3.setStyle("-fx-border-color: red");
                quant3.clear();
                quant3.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant3.setStyle("-fx-border-color: black");
                quant3.setPromptText("Quantity");
            }
            if (!quant4.getText().isEmpty() & isInt(quant4.getText())) {
                seminaire.addNourriture(new Nourriture(petitDejeuner.getNom(), petitDejeuner.getPrixUnite(),Integer.parseInt(quant4.getText()), false, true, false));
            } else if (!isInt(quant4.getText()) & !quant4.getText().isEmpty()) {
                quant4.setStyle("-fx-border-color: red");
                quant4.clear();
                quant4.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant4.setStyle("-fx-border-color: black");
                quant4.setPromptText("Quantity");
            }
        }
        //Ajout de nourriture pour les autres types d'évènement
        else if (evenement != null){
            LOGGER.info("ajout d'un menu pour l'évènement de nom: "+evenement.getNom());
            if (!quant1.getText().isEmpty() & isInt(quant1.getText())) {
                evenement.addNourriture(new Nourriture(pizza.getNom(), pizza.getPrixUnite(),Integer.parseInt(quant1.getText()), false, true, false));
            } else if (!isInt(quant1.getText()) & !quant1.getText().isEmpty()) {
                quant1.setStyle("-fx-border-color: red");
                quant1.clear();
                quant1.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant1.setStyle("-fx-border-color: black");
                quant1.setPromptText("Quantity");
            }
            if (!quant2.getText().isEmpty() & isInt(quant2.getText())) {
                evenement.addNourriture(new Nourriture(burger.getNom(), burger.getPrixUnite(),Integer.parseInt(quant2.getText()), false, true, false));
            } else if (!isInt(quant2.getText()) & !quant2.getText().isEmpty()) {
                quant2.setStyle("-fx-border-color: red");
                quant2.clear();
                quant2.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant2.setStyle("-fx-border-color: black");
                quant2.setPromptText("Quantity");
            }
            if (!quant3.getText().isEmpty() & isInt(quant3.getText())) {
                evenement.addNourriture(new Nourriture(glace.getNom(), glace.getPrixUnite(),Integer.parseInt(quant3.getText()), false, true, false));
            } else if (!isInt(quant3.getText()) & !quant3.getText().isEmpty()) {
                quant3.setStyle("-fx-border-color: red");
                quant3.clear();
                quant3.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant3.setStyle("-fx-border-color: black");
                quant3.setPromptText("Quantity");
            }
            //Changement de boissons pour le type Team Building
            if (!quant4.getText().isEmpty() & isInt(quant4.getText())) {
                if (evenement.getType() == TypeEvenement.TEAMBUILDING) {
                    evenement.addNourriture(new Nourriture(soda.getNom(), soda.getPrixUnite(), Integer.parseInt(quant4.getText()), true, true, false));
                } else {
                    evenement.addNourriture(new Nourriture(biere.getNom(), biere.getPrixUnite(), Integer.parseInt(quant4.getText()), true, true, false));
                }
            } else if (!isInt(quant4.getText()) & !quant4.getText().isEmpty()) {
                quant4.setStyle("-fx-border-color: red");
                quant4.clear();
                quant4.setPromptText("Invalid input");
                LOGGER.warning("quantité invalide");
                erreurEntree = true;
            } else {
                quant4.setStyle("-fx-border-color: black");
                quant4.setPromptText("Quantity");
            }
        }
        if (!erreurEntree) {
            back(event);
        }
    }

    // ---------------------------- Détection erreur -------------------------------

    /**
     * Permet de savoir si une chaîne peut être un entier ou non
     *
     * @param strNum chaîne à tester
     * @return Vrai si la chaîne peut être convertie en entier, faux si non
     */
    public static boolean isInt(String strNum) {
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            LOGGER.severe("le nombre doit etre un entier");
            return false;
        }
        return true;
    }



    // --------------------- Commun -------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {

            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition des évènements
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void back(ActionEvent event) throws IOException, ExceptionInterface {
        if (seminaire != null) {
            LOGGER.info("changement interface précédente en cours");
            Parent parent;
            ModifyEventControleur modifyEventControleur2 = new ModifyEventControleur(genEvent, null, seminaire);
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
                fxmlLoader.setController(modifyEventControleur2);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur2.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        } else {
            LOGGER.info("changement interface précédente en cours");
            ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
                fxmlLoader.setController(modifyEventControleur);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        }

    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition pour les évènements classés dans les archives
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void backArchives(ActionEvent event) throws IOException, ExceptionInterface {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-event-view.fxml"));
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
        Parent parent;
        try {
            fxmlLoader.setController(modifyEventControleur);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        modifyEventControleur.initializeModify();
    }
}
