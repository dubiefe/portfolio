package fr.uga.iut2.genevent.modele;

import java.io.Serializable;

public class Invite implements Serializable {

    private String nom;
    private String mail;

    /**
     * Constructeur Invite avec comme paramètres le nom et le mail de l'invité
     * @param nom le nom de l'invité
     * @param mail le mail de l'invité
     */
    public Invite(String nom, String mail) {
        setNom(nom);
        setMail(mail);
    }

    /**
     * Permet d'acceder au nom de l'invité
     * @return le nom de l'invité
     */
    public String getNom() {
        return nom;
    }

    /**
     * Permet d'attribuer un nom à un invité
     * @param nom le nom d'un invité
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Permet d'acceder au mail d'un invité
     * @return le mail d'un invité
     */
    public String getMail() {
        return mail;
    }

    /**
     * Permet d'attribuer un mail à un invité
     * @param mail le mail d'un invité
     */
    public void setMail(String mail) {
        this.mail = mail;
    }
}
