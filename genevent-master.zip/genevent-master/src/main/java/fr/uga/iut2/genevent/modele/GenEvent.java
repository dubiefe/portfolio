package fr.uga.iut2.genevent.modele;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class GenEvent implements Serializable {

    private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation

    private ArrayList<Evenement> evenements = new ArrayList<>();
    private ArrayList<Evenement> listeParty = new ArrayList<>();
    private ArrayList<Evenement> listeInte = new ArrayList<>();
    private ArrayList<Evenement> listeConf = new ArrayList<>();
    private ArrayList<Evenement> listeSeminaire = new ArrayList<>();
    private ArrayList<Evenement> listeTeamBuilding = new ArrayList<>();
    private ArrayList<Evenement> listeAfterwork = new ArrayList<>();



        /**
         * Constructeur de la classe GenEvent.
         * Initialise les listes de conventions, de conférenciers, de gérants et de lieux.
         */
        public GenEvent() {
        }


    /**
     * Crée un nouvel événement et l'ajoute à la liste des événements
     * @param nom le nom de l'évènement
     * @param lieu le lieu de l'évènement
     * @param date la date de l'évènement
     * @param type le type d'évènement
     * @param budget le budget de l'évènement
     * @return true si le nom de l'évènement n'exister pas et donc l'évènement à était crée sinon false et l'évènement n'est pas crée
     */
   /* public boolean nouvelEvenement(String nom, String lieu, LocalDate date, TypeEvenement type, double budget) {
            if (!eventExist(nom)) {
                Evenement evt = new Evenement(nom,lieu,date, type, budget);
                evenements.add(evt);
                return true;
            }
            else{return false;}
    }*/

    /**
     * Ajoute un événement à la collection d'événements et le trie dans les listes spécifiques par type d'événement.
     *
     * @param evenement Événement à ajouter à la collection.
     */
    public void addEvent(Evenement evenement){
        evenements.add(evenement);
        listeParty = trieEvent(evenements, TypeEvenement.POT_DE_DEPART);
        listeInte = trieEvent(evenements, TypeEvenement.SOIREE_DINTEGRATION);
        listeConf = trieEvent(evenements, TypeEvenement.CONFERENCE);
        listeSeminaire = trieEvent(evenements, TypeEvenement.SEMINAIRE);
        listeTeamBuilding = trieEvent(evenements, TypeEvenement.TEAMBUILDING);
        listeAfterwork = trieEvent(evenements, TypeEvenement.SOIREE_AFTERWORK);
    }

    /**
     * @param nom le nom de l'évènement
     * @return true si le nom de l'évènement existe déjà false sinon
     */
    public boolean eventExist(String nom) {
        int i = 0;
        while (i < evenements.size() && evenements.get(i).getNom().compareTo(nom) != 0) {i++;}
        if (i < evenements.size()) {return true;}
        else {return false;}
    }

    /**
     * @param nom le nom de l'évènement
     * @param lieu le lieu du séminaire
     * @param dateDebut la date du début du séminaire
     * @param type le type d'évènement ici séminaire
     * @param budget le budget pour l'évènement
     * @param datefin la date de fin du séminaire
     * @return true si l'évènement à était crée false sinon
     */
   /* public boolean nouveauSeminaire(String nom, String lieu, LocalDate dateDebut, TypeEvenement type, double budget, LocalDate datefin) {
        if (!eventExist(nom)) {
            Seminaire evt = new Seminaire(nom,lieu,dateDebut, type, budget, datefin);
            evenements.add(evt);
            return true;
        }
        else{return false;}
    }*/

    /**
     * Trie une liste d'événements en fonction du type spécifié.
     *
     * @param evenements La liste d'événements à trier.
     * @param evenement Le type d'événement par lequel trier la liste.
     * @return Une liste d'événements filtrée par le type spécifié.
     */
    public ArrayList<Evenement> trieEvent(ArrayList<Evenement> evenements, TypeEvenement evenement){
        ArrayList<Evenement> res = new ArrayList<>();
        for (Evenement evenement1 : evenements){
            if (evenement1.getType().compareTo(evenement) == 0){
                res.add(evenement1);
            }
        }
        return res;
    }

    /**
     * Récupère la liste complète de tous les événements.
     *
     * @return La liste complète de tous les événements.
     */
    public ArrayList<Evenement> getEvenements() {
        return evenements;
    }

    /**
     * Récupère la liste d'événements associée à un type d'événement spécifié.
     *
     * @param typeEvenement Le type d'événement pour lequel récupérer la liste.
     * @return Une liste d'événements correspondant au type spécifié, ou une liste vide si aucun événement de ce type n'existe.
     */
    public ArrayList<Evenement> getListe(TypeEvenement typeEvenement) {
        if (typeEvenement == TypeEvenement.POT_DE_DEPART){
            return listeParty;
        }else if (typeEvenement == TypeEvenement.SOIREE_DINTEGRATION) {
            return listeInte;
        }else if (typeEvenement == TypeEvenement.SEMINAIRE) {
            return listeSeminaire;
        }else if (typeEvenement == TypeEvenement.SOIREE_AFTERWORK) {
            return listeAfterwork;
        }else if (typeEvenement == TypeEvenement.CONFERENCE) {
            return listeConf;
        }else if (typeEvenement == TypeEvenement.TEAMBUILDING) {
            return listeTeamBuilding;
        }else  {
            return new ArrayList<Evenement>();
        }
    }
}
