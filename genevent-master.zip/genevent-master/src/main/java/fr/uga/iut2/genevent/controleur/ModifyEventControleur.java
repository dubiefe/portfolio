package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import static java.lang.Double.parseDouble;

public class ModifyEventControleur {

    //Attributs
    private Evenement evenement;
    private Seminaire seminaire;
    public static final Logger LOGGER = Logger.getLogger(ControleurAccueil.class.getName());
    @FXML private ComboBox<String> txtLieu;
    @FXML private DatePicker txtDate, txtDateFin;
    @FXML private TextField txtBudget, txtName;
    @FXML private Label txtType, titre, invNameEvent, invDateEvent, invPlaceEvent;
    private GenEvent genEvent;
    private Stage stage;

    //Constructeurs
    public ModifyEventControleur(GenEvent genEvent, Stage stage, Evenement evenement) {
        this.stage = stage;
        this.genEvent = genEvent;
        this.evenement = evenement;
    }

    public ModifyEventControleur(GenEvent genEvent, Stage stage, Seminaire seminaire) {
        this.stage = stage;
        this.genEvent = genEvent;
        this.seminaire = seminaire;
    }

    //Méthodes

    /**
     * Permet d'avoir accès à la valeur du type de l'évènement
     *
     * @return la valuer du type
     */
    public Label getTxtType() {
        return txtType;
    }

    /**
     * Permetr d'avoir accès aux valeurs de la comboBox contenant les lieux
     *
     * @return la valeur contenue dans la comboBox
     */
    public ComboBox getTxtLieu() {
        return txtLieu;
    }


    /* ---------------------------------------------------------- Create ---------------------------------------------------------- */

    /**
     * Crée un évènement avec les données remplies par l'utilisateur
     * Gère les erreurs de saisie
     *
     * @param event l'évènement clic sur le bouton 'Create'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void createEvent(ActionEvent event) throws IOException {

        boolean nameError = false;
        for (int i = 0; i < genEvent.getEvenements().size(); i++) {
            if (txtName.getText().equals(genEvent.getEvenements().get(i).getNom())) {
                LOGGER.severe("le nom de cette évènement existe déjà");
                nameError = true;
            }
        }

        if (txtName.getText().isEmpty()) {
            txtName.setStyle("-fx-border-color: red");
            txtName.setPromptText("The name must not be empty");
        }
        if (txtDate.getValue() == null) {
            txtDate.setStyle("-fx-border-color: red");
            txtDate.setPromptText("The date must not be empty");
            LOGGER.warning("la date ne doit pas etre vide");
        } else if (!txtDate.getValue().isAfter(LocalDate.now())) {
            txtDate.getEditor().clear();
            txtDate.setStyle("-fx-border-color: red");
            txtDate.setPromptText("The date must be in the future");
            LOGGER.warning("la date doit etre dans le futur");
        }
        if (txtType.getText().equals("Seminar")) {
            if (txtDateFin.getValue() == null) {
                txtDateFin.setStyle("-fx-border-color: red");
                txtDateFin.setPromptText("The date must not be empty");
                LOGGER.warning("la date de fin ne doit pas etre vide");
            }
        }
        if (txtLieu.getValue() == null || txtLieu.getValue().isEmpty()) {
            txtLieu.setStyle("-fx-border-color: red");
            txtLieu.setPromptText("The place must not be empty");
            LOGGER.warning("le lieu ne doit pas etre vide");
        }
        if (txtBudget.getText().isEmpty()) {
            txtBudget.setStyle("-fx-border-color: red");
            txtBudget.setPromptText("The budget must not be empty");
            LOGGER.warning("le budget ne doit pas etre vide");
        } else if (!isDouble(txtBudget.getText())) {
            txtBudget.setStyle("-fx-border-color: red");
            txtBudget.clear();
            txtBudget.setPromptText("The budget must be a number");
        } else if (Double.parseDouble(txtBudget.getText()) < 0) {
            txtBudget.setStyle("-fx-border-color: red");
            txtBudget.clear();
            txtBudget.setPromptText("The budget must be greater than 0");
            LOGGER.warning("le budget ne doit pas etre négatif");
        }

        if (!txtName.getText().isEmpty()) {
            txtName.setStyle("-fx-border-color: black");
        }
        if (txtDate.getValue() != null && txtDate.getValue().isAfter(LocalDate.now())) {
            txtDate.setStyle("-fx-border-color: black");
        }
        if (txtLieu.getValue() != null && !txtLieu.getValue().isEmpty()) {
            txtLieu.setStyle("-fx-border-color: black");
        }
        if (!txtBudget.getText().isEmpty() && isDouble(txtBudget.getText()) && !(Double.parseDouble(txtBudget.getText()) < 0)) {
            txtBudget.setStyle("-fx-border-color: black");
        }
        if (!txtName.getText().isEmpty() && txtDate.getValue() != null && txtLieu.getValue() != null
                && !txtBudget.getText().isEmpty() && !nameError && txtDate.getValue().isAfter(LocalDate.now())
                && isDouble(txtBudget.getText()) && !txtLieu.getValue().isEmpty()
                && !(Double.parseDouble(txtBudget.getText()) < 0)) {
            LocalDate date = txtDate.getValue();
            LocalDate dateFin = date;
            if (txtType.getText().equals("Seminar")) {
                dateFin = txtDateFin.getValue();
            }
            Double budget = Double.valueOf(txtBudget.getText());
            String lieu = txtLieu.getValue();
            if (chooseType(txtType.getText()).equals(TypeEvenement.SEMINAIRE)) {
                Seminaire seminaire1 = new Seminaire(txtName.getText(), lieu, date, chooseType(txtType.getText()), budget, dateFin);
                finCreationSeminaire(seminaire1);
                LOGGER.info("création du séminaire réussi");
            } else {
                Evenement evenement = new Evenement(txtName.getText(), lieu, date, chooseType(txtType.getText()), budget);
                finCreationEvenement(evenement);
                LOGGER.info("création de l'évènement réussi");
            }
        }
    }

    /**
     * Convertit une chaîne en type d'événement correspondant
     *
     * @param choix chaîne à convertir
     * @return TypeEvenement correspondant à la chaîne
     */
    public TypeEvenement chooseType(String choix) {
        if (choix.compareTo("Leaving party") == 0) {
            return TypeEvenement.POT_DE_DEPART;
        } else if (choix.compareTo("Integration party") == 0) {
            return TypeEvenement.SOIREE_DINTEGRATION;
        } else if (choix.compareTo("Conference") == 0) {
            return TypeEvenement.CONFERENCE;
        } else if (choix.compareTo("Seminar") == 0) {
            return TypeEvenement.SEMINAIRE;
        } else if (choix.compareTo("Team Building") == 0) {
            return TypeEvenement.TEAMBUILDING;
        } else {
            return TypeEvenement.SOIREE_AFTERWORK;
        }
    }

    /**
     * Ajoute un séminaire à la liste des séminaire
     * Retourne sur la page de la liste des séminaires
     *
     * @param seminaire1 séminaire  à ajouter
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void finCreationSeminaire(Seminaire seminaire1) throws IOException {
        genEvent.addEvent(seminaire1);
        seminaire = seminaire1;
        Stage stagePopup = (Stage) txtType.getScene().getWindow();
        stagePopup.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
        fxmlLoader.setController(this);
        Parent parent = fxmlLoader.load();
        Scene scene = new Scene(parent, 1000, 600);
        stage.setScene(scene);
        scene.getWindow().sizeToScene();

        titre.setText(seminaire1.getNom());
        txtName.setText(seminaire1.getNom());
        txtBudget.setText(String.valueOf(seminaire1.getBudget()));
        txtDate.setValue(seminaire1.getDate());
        txtLieu.setValue(seminaire1.getLieu());
        txtType.setText("Seminar");
        txtDateFin.setValue(seminaire1.getDateFin());
    }

    /**
     * Ajoute l'évènement à la liste d'évènement
     * Reviens sur la page de la liste d'évènements
     *
     * @param evenement1 évènement à créer et ajouter à la liste d'évènement
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void finCreationEvenement(Evenement evenement1) throws IOException {
        genEvent.addEvent(evenement1);
        evenement = evenement1;
        Stage stagePopup = (Stage) txtType.getScene().getWindow();
        stagePopup.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
        fxmlLoader.setController(this);
        Parent parent = fxmlLoader.load();
        Scene scene = new Scene(parent, 1000, 600);
        stage.setScene(scene);
        scene.getWindow().sizeToScene();

        titre.setText(evenement1.getNom());
        txtName.setText(evenement1.getNom());
        txtBudget.setText(String.valueOf(evenement1.getBudget()));
        txtDate.setValue(evenement1.getDate());
        txtLieu.setValue(evenement1.getLieu());
        if (evenement1.getType().equals(TypeEvenement.POT_DE_DEPART)) {
            txtType.setText("Leaving party");
        } else if (evenement1.getType().equals(TypeEvenement.SOIREE_DINTEGRATION)) {
            txtType.setText("Integration party");
        } else if (evenement1.getType().equals(TypeEvenement.CONFERENCE)) {
            txtType.setText("Conference");
        } else if (evenement1.getType().equals(TypeEvenement.TEAMBUILDING)) {
            txtType.setText("Team Building");
        } else if (evenement1.getType().equals(TypeEvenement.SOIREE_AFTERWORK)) {
            txtType.setText("Afterwork Party");
        }
    }

    /* ---------------------------------------------------------- Modify ---------------------------------------------------------- */

    /**
     * Initialise la page de modification d'un évènement
     * Reprend les informations de l'évènement
     */
    public void initializeModify() {
        LOGGER.info("modification de l'évènement en cours");
        if (seminaire != null) {
            titre.setText(seminaire.getNom());
            txtName.setText(seminaire.getNom());
            txtBudget.setText(String.valueOf(seminaire.getBudget()));
            txtDate.setValue(seminaire.getDate());
            txtDateFin.setValue(seminaire.getDateFin());
            txtLieu.setValue(seminaire.getLieu());
            txtType.setText("Seminar");
        } else if (evenement != null) {
            titre.setText(evenement.getNom());
            txtName.setText(evenement.getNom());
            txtBudget.setText(String.valueOf(evenement.getBudget()));
            txtDate.setValue(evenement.getDate());
            txtLieu.setValue(evenement.getLieu());
            if (evenement.getType().equals(TypeEvenement.POT_DE_DEPART)) {
                txtType.setText("Leaving party");
            } else if (evenement.getType().equals(TypeEvenement.SOIREE_DINTEGRATION)) {
                txtType.setText("Integration party");
            } else if (evenement.getType().equals(TypeEvenement.CONFERENCE)) {
                txtType.setText("Conference");
            } else if (evenement.getType().equals(TypeEvenement.TEAMBUILDING)) {
                txtType.setText("Team Building");
            } else if (evenement.getType().equals(TypeEvenement.SOIREE_AFTERWORK)) {
                txtType.setText("Afterwork Party");
            }
        }
        LOGGER.info("modification de l'évènement réussi");
    }

    /**
     * Applique les modifications sur l'évènement courant
     * Gestion des erreurs
     *
     * @param event évènement à modifier
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void applyModif(ActionEvent event) throws IOException, ExceptionInterface {

        boolean nameError = false;
        LOGGER.info("application des modifications en cours");
        for (int i = 0; i < genEvent.getEvenements().size(); i++) {
            if (evenement != null && txtName.getText().equals(genEvent.getEvenements().get(i).getNom()) && !txtName.getText().equals(evenement.getNom())) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "This name already exist.", ButtonType.OK);
                alert.showAndWait();
                LOGGER.severe("This name already exist.");
                nameError = true;
            } else if (seminaire != null && txtName.getText().equals(genEvent.getEvenements().get(i).getNom()) && !txtName.getText().equals(seminaire.getNom())) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "This name already exist.", ButtonType.OK);
                alert.showAndWait();
                LOGGER.severe("This name already exist.");
                nameError = true;
            }
        }

        if (txtName.getText().isEmpty()) {
            txtName.setStyle("-fx-border-color: red");
            txtName.setPromptText("The name must not be empty");
            LOGGER.warning("le nom ne peut pas etre vide");
        }
        if (txtDate.getValue() == null) {
            txtDate.setStyle("-fx-border-color: red");
            txtDate.setPromptText("The date must not be empty");
            LOGGER.warning("la date ne peut pas etre vide");
        }
        if (!txtDate.getValue().isAfter(LocalDate.now())) {
            txtDate.getEditor().clear();
            txtDate.setStyle("-fx-border-color: red");
            txtDate.setPromptText("The date must be in the future");
        }
        if (txtType.getText().equals("Seminar")) {
            if (txtDateFin.getValue() == null) {
                txtDateFin.setStyle("-fx-border-color: red");
                txtDateFin.setPromptText("The date must not be empty");
                LOGGER.warning("la date de fin ne doit pas etre vide");
            }
        }
        if (txtLieu.getValue() == null || txtLieu.getValue().isEmpty()){
            txtLieu.setStyle("-fx-border-color: red");
            txtLieu.setPromptText("The place must not be empty");
        }
        if (txtBudget.getText().isEmpty()){
            txtBudget.setStyle("-fx-border-color: red");
            txtBudget.setPromptText("The budget must not be empty");
        } else if (!isDouble(txtBudget.getText())) {
            txtBudget.setStyle("-fx-border-color: red");
            txtBudget.clear();
            txtBudget.setPromptText("The budget must be a number");
            LOGGER.warning("le budget doit etre un chiffre");
        } else if (evenement != null && parseDouble(txtBudget.getText()) < (evenement.getBudget() - evenement.getBudgetCourrant()) || parseDouble(txtBudget.getText()) < 0) {
            txtBudget.setStyle("-fx-border-color: red");
            txtBudget.clear();
            txtBudget.setPromptText("The budget can't be lower than your expenses");
            LOGGER.warning("le budget doit etre supérieur aux dépenses");
        } else if (seminaire != null && parseDouble(txtBudget.getText()) < (seminaire.getBudget() - seminaire.getBudgetCourrant())  || parseDouble(txtBudget.getText()) < 0) {
            txtBudget.setStyle("-fx-border-color: red");
            txtBudget.clear();
            txtBudget.setPromptText("The budget can't be lower than your expenses");
            LOGGER.warning("le budget doit etre supérieur aux dépenses");
        }
        if (!txtName.getText().isEmpty()) {
            txtName.setStyle("-fx-border-color: black");
        }
        if (txtDate.getValue() != null && txtDate.getValue().isAfter(LocalDate.now())) {
            txtDate.setStyle("-fx-border-color: black");
        }
        if (txtLieu.getValue() != null && !txtLieu.getValue().isEmpty()) {
            txtLieu.setStyle("-fx-border-color: black");
        }
        if (evenement != null && !txtBudget.getText().isEmpty() && isDouble(txtBudget.getText()) && parseDouble(txtBudget.getText()) >= (evenement.getBudget() - evenement.getBudgetCourrant()) && parseDouble(txtBudget.getText()) >= 0){
            txtBudget.setStyle("-fx-border-color: black");
        } else if (seminaire != null && !txtBudget.getText().isEmpty() && isDouble(txtBudget.getText()) && parseDouble(txtBudget.getText()) >= seminaire.getBudgetCourrant() && parseDouble(txtBudget.getText()) >= 0){
            txtBudget.setStyle("-fx-border-color: black");
        }
        if (evenement != null) {
            if (!txtName.getText().isEmpty() && txtDate.getValue() != null && txtLieu.getValue() != null &&
                    !txtLieu.getValue().isEmpty() && !txtBudget.getText().isEmpty() && !nameError
                    && isDouble(txtBudget.getText()) && txtDate.getValue().isAfter(LocalDate.now())
                    && (parseDouble(txtBudget.getText()) >= (evenement.getBudget() - evenement.getBudgetCourrant()))) {
                evenement.setNom(txtName.getText());
                evenement.setLieu(txtLieu.getValue());
                evenement.setDate(txtDate.getValue());
                evenement.setBudget(Double.parseDouble(txtBudget.getText()));
                LOGGER.info("les informations de l'évènement sont sauvegardé");


                ControleurListe controleurListe = new ControleurListe(genEvent);
                Parent parent;
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
                    fxmlLoader.setController(controleurListe);
                    parent = fxmlLoader.load();
                } catch (IOException e) {
                    throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
                }
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurListe.setType(new Label(txtType.getText()));
                controleurListe.setTypeEvenement(evenement.getType());
                controleurListe.initialize();
            }
        } else if (seminaire != null) {
            if (!txtName.getText().isEmpty() && txtDate.getValue() != null && txtLieu.getValue() != null &&
                    !txtLieu.getValue().isEmpty() && !txtBudget.getText().isEmpty() && !nameError
                    && isDouble(txtBudget.getText()) && txtDate.getValue().isAfter(LocalDate.now())
                    && txtDateFin.getValue().isAfter(LocalDate.now())
                    && (parseDouble(txtBudget.getText()) >= seminaire.getBudgetCourrant())) {
                seminaire.setNom(txtName.getText());
                seminaire.setLieu(txtLieu.getValue());
                seminaire.setDate(txtDate.getValue());
                seminaire.setBudget(Double.parseDouble(txtBudget.getText()));
                LOGGER.info("les informations de l'évènement sont sauvegardé");


                ControleurListe controleurListe = new ControleurListe(genEvent);
                Parent parent;
                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
                    fxmlLoader.setController(controleurListe);
                    parent = fxmlLoader.load();
                } catch (IOException e) {
                    throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
                }
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurListe.setType(new Label(txtType.getText()));
                controleurListe.setTypeEvenement(seminaire.getType());
                controleurListe.initialize();
            }
        }
    }

    /**
     * Affiche un pop up pour supprimer un évènement
     *
     * @param event l'évènement clic sur le bouton 'delete'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteEventPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        Stage stage = new Stage();
        Node node = (Node) event.getSource();
        Scene mainScene = node.getScene();
        Stage mainStage = (Stage) mainScene.getWindow();
        if (evenement != null) {
            LOGGER.info("c'est un évènement");
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, mainStage, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/delete-event-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = new Scene(parent, 400, 200);
            stage.setScene(scene);
            stage.show();
            LOGGER.info("Changement de la page pour supprimer un évènement réussis");
        } else if (seminaire != null) {
            LOGGER.info("c'est un séminaire");
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, mainStage, seminaire);
            Parent parent;
            try {
                FXMLLoader fxmlLoader2 = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/delete-event-view.fxml"));
                fxmlLoader2.setController(controleurNewAndDelete);
                parent = fxmlLoader2.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = new Scene(parent, 400, 200);
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Affiche un pop up pour supprimer un évènement placé dans les archives
     *
     * @param event l'évènement de clic sur le bouton 'delete'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteEventArchivesPopUp(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        Node node = (Node) event.getSource();
        Scene mainScene = node.getScene();
        Stage mainStage = (Stage) mainScene.getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-delete-event-view.fxml"));
        ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, mainStage, evenement);
        fxmlLoader.setController(controleurNewAndDelete);
        Parent parent = fxmlLoader.load();
        Scene scene = new Scene(parent, 400, 200);
        stage.setScene(scene);
        stage.show();
    }

    //Boutons de modification

    /**
     * Redirige sur la page avec le budget et les dépenses de l'évènement
     *
     * @param event l'évènement clic sur le bouton 'See Budget'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void seeBudget(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir le budget en cours");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/budget-view.fxml"));
            if (evenement != null) {
                ControleurBudget controleurBudget = new ControleurBudget(genEvent, evenement);
                fxmlLoader.setController(controleurBudget);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurBudget.initializeBudget();
            } else if (seminaire != null) {
                ControleurBudget controleurBudget = new ControleurBudget(genEvent, seminaire);
                fxmlLoader.setController(controleurBudget);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurBudget.initializeBudget();
                LOGGER.info("Changement de la page pour voir le budget réussis");
            }
        } catch(IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }

    }

    /**
     * Redirige sur la page pour éditer le matériel de l'évènement
     *
     * @param event l'évènement clic sur le bouton 'Edit Material'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void editMaterial(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les materiels en cours");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/material-view.fxml"));
            if (evenement != null) {
                ControleurMaterial controleurMaterial = new ControleurMaterial(genEvent, evenement);
                fxmlLoader.setController(controleurMaterial);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurMaterial.initializeMaterial();
            } else if (seminaire != null) {
                ControleurMaterial controleurMaterial = new ControleurMaterial(genEvent, seminaire);
                fxmlLoader.setController(controleurMaterial);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurMaterial.initializeMaterial();
                LOGGER.info("Changement de la page pour voir les materiels réussis");
            }
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }

    }

    /**
     * Redirige vers la page pour éditer la nourriture
     *
     * @param event l'évènement clic sur le bouton 'Edit Menu'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void editMenu(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les menus en cours");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/food-view.fxml"));
            if (evenement != null) {
                ControleurFood controleurFood = new ControleurFood(genEvent, evenement);
                fxmlLoader.setController(controleurFood);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurFood.initializeFood();
            } else if (seminaire != null) {
                ControleurFood controleurFood = new ControleurFood(genEvent, seminaire);
                fxmlLoader.setController(controleurFood);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurFood.initializeFood();
                LOGGER.info("Changement de la page pour voir les menus réussis");
            }
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
    }

    /**
     * Redirige vers la page pour éditer la liste d'invités
     *
     * @param event l'évènement clic sur le bouton 'Edit Guests'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void editGuest(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les invités en cours");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/guest-view.fxml"));
            if (evenement != null) {
                ControleurGuest controleurGuest = new ControleurGuest(genEvent, evenement);
                fxmlLoader.setController(controleurGuest);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurGuest.initializeInvite();
            } else if (seminaire != null) {
                ControleurGuest controleurGuest = new ControleurGuest(genEvent, seminaire);
                fxmlLoader.setController(controleurGuest);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurGuest.initializeInvite();
                LOGGER.info("Changement de la page pour voir les invités réussis");
            }
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
    }

    /**
     * Redirige vers la page d'édition de la playlist
     *
     * @param event l'évènement clic sur le bouton 'Edit Playlist'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void editPlaylist(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les playlists en cours");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/playlist-view.fxml"));
            if (evenement != null) {
                ControleurPlaylist controleurPlaylist = new ControleurPlaylist(genEvent, evenement);
                fxmlLoader.setController(controleurPlaylist);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurPlaylist.initializePlaylist();
            } else if (seminaire != null) {
                ControleurPlaylist controleurPlaylist = new ControleurPlaylist(genEvent, seminaire);
                fxmlLoader.setController(controleurPlaylist);
                Parent parent = fxmlLoader.load();
                Scene scene = ((Node) event.getSource()).getScene();
                scene.setRoot(parent);
                scene.getWindow().sizeToScene();
                controleurPlaylist.initializePlaylist();
                LOGGER.info("Changement de la page pour voir les playlists réussies");
            }
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
    }

    /**
     * Redirige vers la page d'édition de l'hotel
     *
     * @param event l'évènement clic sur le bouton 'Edit PLaylist'
     * @throws IOException si le fichier FXML ne peut pas charger
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    private void editHotel(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir/modifier l'hotel en cours");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/hotel-view.fxml"));
            ControleurHotel controleurHotel = new ControleurHotel(genEvent, seminaire);
            fxmlLoader.setController(controleurHotel);
            Parent parent = fxmlLoader.load();
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurHotel.initializeHotel();
            LOGGER.info("Changement de la page pour voir/modifier l'hotel réussi");
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
    }


    /**
     * Affiche un pop up montrant un format d'invitation pour un évènement
     *
     * @param event l'évènement clic sur le bouton 'Generate invitation'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void generateInvitation(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour généré des invitations en cours");
        Stage stage = new Stage();
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/invitation-view.fxml"));
            fxmlLoader.setController(this);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = new Scene(parent, 600, 400);
        stage.setScene(scene);
        stage.show();
        if (evenement != null) {
            invNameEvent.setText(evenement.getNom());
            invDateEvent.setText("On " + evenement.getDate());
            invPlaceEvent.setText("At " + evenement.getLieu());
            LOGGER.info("Changement de la page pour généré des invites réussies");
        } else if (seminaire != null) {
            invNameEvent.setText(seminaire.getNom());
            invDateEvent.setText("From " + seminaire.getDate() + " to " + seminaire.getDateFin());
            invPlaceEvent.setText("At " + seminaire.getLieu());
        }
        LOGGER.info("Changement de la page pour généré des invitations réussi");
    }

    /**
     * Affiche un pop up affichant un format d'invitation pour un évènement classé dans archives
     *
     * @param event l'évènement clic sur le bouton 'See Invitation'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void seeInvitation(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les archives des invites en cours");
        Stage stage = new Stage();
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archives-invitation-view.fxml"));
            fxmlLoader.setController(this);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = new Scene(parent, 600, 400);
        stage.setScene(scene);
        stage.show();
        if (evenement != null) {
            invNameEvent.setText(evenement.getNom());
            invDateEvent.setText("On " + evenement.getDate());
            invPlaceEvent.setText("At " + evenement.getLieu());
        } else if (seminaire != null) {
            invNameEvent.setText(seminaire.getNom());
            invDateEvent.setText("From " + seminaire.getDate() + " to " + seminaire.getDateFin());
            invPlaceEvent.setText("At " + seminaire.getLieu());
        }
    }

    /**
     * Annule la génération d'une invitation
     * Revient sur la page de la modification de l'évènement
     *
     * @param event l'évènement clic sur le bouton 'Cancel'
     */
    @FXML
    public void cancelInvitation(ActionEvent event) {
        LOGGER.info("Fermeture de la popup de confirmation");
        Scene scene = invPlaceEvent.getScene();
        Stage stage1 = (Stage) scene.getWindow();
        stage1.close();
    }

    /**
     * Revient sur la page précédente
     *
     * @param event l'évènement clic sur le bouton 'Cancel'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void cancel(ActionEvent event) throws IOException {
        Scene scene = txtType.getScene();
        Stage stage = (Stage) scene.getWindow();
        stage.close();
    }

    /**
     * Définit le type d'événement à afficher
     *
     * @param txtType1 Label contenant le type d'événement
     */
    public void setTxtType(Label txtType1) {
        txtType.setText(txtType1.getText());
        titre.setText("New " + txtType.getText());
    }

    // --------------------- Commun -------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface setting réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }


    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition des évènements
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */

    @FXML
    private void retour(ActionEvent event) throws IOException {
        Scene scene = txtType.getScene();
        Stage stage = (Stage) scene.getWindow();
        stage.close();
        LOGGER.info("Retour sur l'interface précédente réussi");
    }

    /**
     * Convertit une chaîne en type d'événement correspondant
     *
     * @param choix Chaîne représentant le type d'événement
     * @return TypeEvenement correspondant à la chaîne
     */
    public TypeEvenement choixType(String choix) {
        if (choix.compareTo("Leaving party") == 0) {
            return TypeEvenement.POT_DE_DEPART;
        } else if (choix.compareTo("Integration party") == 0) {
            return TypeEvenement.SOIREE_DINTEGRATION;
        } else if (choix.compareTo("Conference") == 0) {
            return TypeEvenement.CONFERENCE;
        } else if (choix.compareTo("Seminar") == 0) {
            return TypeEvenement.SEMINAIRE;
        } else if (choix.compareTo("Team Building") == 0) {
            return TypeEvenement.TEAMBUILDING;
        } else {
            return TypeEvenement.SOIREE_AFTERWORK;
        }
    }

    /*****************************Archives******************************/

    /**
     * Redirige sur la page avec le budget et les dépenses d'un évènement classé dans les archives
     *
     * @param event l'évènement clic sur le bouton 'See Budget'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void seeBudgetArchives(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les archives du budget en cours");
        if (evenement != null) {
            ControleurBudget controleurBudget = new ControleurBudget(genEvent, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-budget-view.fxml"));
                fxmlLoader.setController(controleurBudget);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurBudget.initializeBudget();
        } else if (seminaire != null) {
            ControleurBudget controleurBudget = new ControleurBudget(genEvent, seminaire);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-budget-view.fxml"));
                fxmlLoader.setController(controleurBudget);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurBudget.initializeBudget();
        }
        LOGGER.info("Changement de la page pour voir les archives du budget réussie");
    }

    /**
     * Redirige vers la page permettant de voir le matériel d'un évènement classé dans les archives
     *
     * @param event l'évènement clic sur le bouton 'See Material'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    private void seeMaterialArchives(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les archives des matériels en cours");
        if (evenement != null) {
            ControleurMaterial controleurMaterial = new ControleurMaterial(genEvent, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-material-view.fxml"));
                fxmlLoader.setController(controleurMaterial);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurMaterial.initializeMaterielArchives();
        }else if (seminaire != null) {
            ControleurMaterial controleurMaterial = new ControleurMaterial(genEvent, seminaire);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-material-view.fxml"));
                fxmlLoader.setController(controleurMaterial);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurMaterial.initializeMaterielArchives();
        }
        LOGGER.info("Changement de la page pour voir les archives des matériels réussies");
    }

    /**
     * Redirige vers la page permettant de voir les menus d'un évènement classé dans les archives
     *
     * @param event l'évènement clic sur le bouton 'See Menu'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    private void seeMenuArchives(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les archives des menus en cours");
        if (evenement != null) {
            ControleurFood controleurFood = new ControleurFood(genEvent, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-food-view.fxml"));
                fxmlLoader.setController(controleurFood);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurFood.initializeFood();
        } else if (seminaire != null) {
            ControleurFood controleurFood = new ControleurFood(genEvent, seminaire);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-food-view.fxml"));
                fxmlLoader.setController(controleurFood);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurFood.initializeFood();
        }
        LOGGER.info("Changement de la page pour voir les archives des menus réussis");
    }

    /**
     * Redirige vers la page permettant de voir les invités d'un évènement classé dans les archives
     *
     * @param event l'évènement clic sur le bouton 'See Guests'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    private void seeGuestArchives(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Changement de la page pour voir les archives des invités en cours");
        if (evenement != null) {
            ControleurGuest controleurGuest = new ControleurGuest(genEvent, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-guest-view.fxml"));
                fxmlLoader.setController(controleurGuest);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurGuest.initializeInviteArchives();
        } else if (seminaire != null) {
            ControleurGuest controleurGuest = new ControleurGuest(genEvent, seminaire);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-guest-view.fxml"));
                fxmlLoader.setController(controleurGuest);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurGuest.initializeInvite();
        }
        LOGGER.info("Changement de la page pour voir les archives des invités réussis");
    }

    /**
     * Redirige vers la page permettant de voir la playlist d'un évènement classé dans les archives
     *
     * @param event l'évènement clic sur le bouton 'See Playlist'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void seePlaylistArchives(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-playlist-view.fxml"));
        if (evenement != null) {
            ControleurPlaylist controleurPlaylist = new ControleurPlaylist(genEvent, evenement);
            fxmlLoader.setController(controleurPlaylist);
            Parent parent = fxmlLoader.load();
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurPlaylist.initializePlaylist();
        } else if (seminaire != null) {
            ControleurPlaylist controleurPlaylist = new ControleurPlaylist(genEvent, seminaire);
            fxmlLoader.setController(controleurPlaylist);
            Parent parent = fxmlLoader.load();
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            controleurPlaylist.initializePlaylist();
        }
    }

    /**
     * Affiche un pop up avec un format d'invitation pour un évènement classé dans les archives
     *
     * @param event l'évènement clic sur le bouton 'See Invitation'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    private void seeInvitationArchives(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-invitation-view.fxml"));
        fxmlLoader.setController(this);
        Parent parent = fxmlLoader.load();
        Scene scene = new Scene(parent, 600, 400);
        stage.setScene(scene);
        stage.show();
        if (evenement != null) {
            invNameEvent.setText(evenement.getNom());
            invDateEvent.setText("On " + evenement.getDate());
            invPlaceEvent.setText("At " + evenement.getLieu());
        } else if (seminaire != null) {
            invNameEvent.setText(seminaire.getNom());
            invDateEvent.setText("From " + seminaire.getDate() + " to " + seminaire.getDateFin());
            invPlaceEvent.setText("At " + seminaire.getLieu());
        }
    }

    // ---------------------------- Détection d'erreur ---------------------------------

    /**
     * Permet de savoir si une chaîne peut être transformée en double ou non
     * @param strNum chaîne à tester
     * @return Vrai si la chaîne peut être convertie en double, faux si non
     */
    public static boolean isDouble(String strNum) {
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            LOGGER.severe("le nombre n'a pas le bon format");
            return false;
        }
        return true;
    }

}

