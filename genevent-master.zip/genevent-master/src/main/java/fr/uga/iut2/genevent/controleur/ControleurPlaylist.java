package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class ControleurPlaylist {

    private GenEvent genEvent;
    private Evenement evenement;
    private Seminaire seminaire;
    @FXML private Button playlist1, playlist2, playlist3, playlist4;
    @FXML private Label musique1, musique2, musique3, musique4, musique5;

    //Constructeurs
    public ControleurPlaylist(GenEvent genEvent, Evenement event) {
        this.genEvent = genEvent;
        this.evenement = event;
    }

    public ControleurPlaylist(GenEvent genEvent, Seminaire seminaire) {
        this.genEvent = genEvent;
        this.seminaire = seminaire;
    }

    // ------------ Création des playlist ------------
    // ------------ Playlist n°3 ------------
    private final Musique m1p1 = new Musique("Hey Brother", "Avicii");
    private final Musique m2p1 = new Musique("This is The Life", "Amy MacDonald");
    private final Musique m3p1 = new Musique("Lost on You", "LP");
    private final Musique m4p1 = new Musique("Shape of You", "Ed Sheeran");
    private final Musique m5p1 = new Musique("Formidable", "Stromae");
    private final ArrayList<Musique> p1 = new ArrayList<>(Arrays.asList(m1p1, m2p1, m3p1, m4p1, m5p1));
    // ------------ Playlist n°2 ------------
    private final Musique m1p2 = new Musique("I Want It That Way", "BackStreet Boys");
    private final Musique m2p2 = new Musique("Umbrella", "Rihanna");
    private final Musique m3p2 = new Musique("Ma Philosophie", "Amel Bent");
    private final Musique m4p2 = new Musique("Partenaire Particulier", "Partenaire Particulier");
    private final Musique m5p2 = new Musique("On va s'aimer", "Gilbert Montagnier");
    private final ArrayList<Musique> p2 = new ArrayList<>(Arrays.asList(m1p2, m2p2, m3p2, m4p2, m5p2));
    // ------------ Playlist n°3 ------------
    private final Musique m1p3 = new Musique("Eye Of The Tiger", "Survivor");
    private final Musique m2p3 = new Musique("Happy", "Pharrell Williams");
    private final Musique m3p3 = new Musique("I Gotta Feeling", "The Black Eyed Peas");
    private final Musique m4p3 = new Musique("Cheerleader", "OMI");
    private final Musique m5p3 = new Musique("Uptown Funk", "Marc Ronson ft. Bruno Mars");
    private final ArrayList<Musique> p3 = new ArrayList<>(Arrays.asList(m1p3, m2p3, m3p3, m4p3, m5p3));
    // ------------ Playlist n°4 ------------
    private final Musique m1p4 = new Musique("Last Night", "Chris Anderson ft. DJ Robbie");
    private final Musique m2p4 = new Musique("Macarena", "Los Del Mar");
    private final Musique m3p4 = new Musique("YMCA", "Village People");
    private final Musique m4p4 = new Musique("Jerusalema", "Master KG ft. Nomcebo Zikode");
    private final Musique m5p4 = new Musique("Cotton Eye Joe", "Redneck");
    private final ArrayList<Musique> p4 = new ArrayList<>(Arrays.asList(m1p4, m2p4, m3p4, m4p4, m5p4));

    //Méthodes
    // ---------------------------------------------- Playlist ----------------------------------------------

    /**
     * Initialise la liste des playlists (4)
     * Ajoute les conteneurs et le style nécessaire
     */
    @FXML
    public void initializePlaylist() {
        // ------------ Repartition des playlist par défaut ------------
        if (evenement != null && evenement.getNumPlaylist() == 0) {
            if (evenement.getType() == TypeEvenement.POT_DE_DEPART || evenement.getType() == TypeEvenement.SOIREE_DINTEGRATION) {
                evenement.setNumPlaylist(1);
            } else if (evenement.getType() == TypeEvenement.SOIREE_AFTERWORK) {
                evenement.setNumPlaylist(2);
            } else if (evenement.getType() == TypeEvenement.TEAMBUILDING) {
                evenement.setNumPlaylist(4);
            } else {
                evenement.setNumPlaylist(3);
            }
        } else if (seminaire != null && seminaire.getNumPlaylist() == 0) {
            seminaire.setNumPlaylist(3);
        }

        // ------------ Affichage de la page ------------
        if (evenement != null && evenement.getNumPlaylist() == 1 || seminaire != null && seminaire.getNumPlaylist() == 1) {
            playlist1.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p1.get(0).getNom() + ", " + p1.get(0).getArtiste());
            musique2.setText(p1.get(1).getNom() + ", " + p1.get(1).getArtiste());
            musique3.setText(p1.get(2).getNom() + ", " + p1.get(2).getArtiste());
            musique4.setText(p1.get(3).getNom() + ", " + p1.get(3).getArtiste());
            musique5.setText(p1.get(4).getNom() + ", " + p1.get(4).getArtiste());

        } else if (evenement != null && evenement.getNumPlaylist() == 2 || seminaire != null && seminaire.getNumPlaylist() == 2) {
            playlist2.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p2.get(0).getNom() + ", " + p2.get(0).getArtiste());
            musique2.setText(p2.get(1).getNom() + ", " + p2.get(1).getArtiste());
            musique3.setText(p2.get(2).getNom() + ", " + p2.get(2).getArtiste());
            musique4.setText(p2.get(3).getNom() + ", " + p2.get(3).getArtiste());
            musique5.setText(p2.get(4).getNom() + ", " + p2.get(4).getArtiste());
        } else if (evenement != null && evenement.getNumPlaylist() == 3 || seminaire != null && seminaire.getNumPlaylist() == 3) {
            playlist3.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p3.get(0).getNom() + ", " + p3.get(0).getArtiste());
            musique2.setText(p3.get(1).getNom() + ", " + p3.get(1).getArtiste());
            musique3.setText(p3.get(2).getNom() + ", " + p3.get(2).getArtiste());
            musique4.setText(p3.get(3).getNom() + ", " + p3.get(3).getArtiste());
            musique5.setText(p3.get(4).getNom() + ", " + p3.get(4).getArtiste());
        } else {
            playlist4.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p4.get(0).getNom() + ", " + p4.get(0).getArtiste());
            musique2.setText(p4.get(1).getNom() + ", " + p4.get(1).getArtiste());
            musique3.setText(p4.get(2).getNom() + ", " + p4.get(2).getArtiste());
            musique4.setText(p4.get(3).getNom() + ", " + p4.get(3).getArtiste());
            musique5.setText(p4.get(4).getNom() + ", " + p4.get(4).getArtiste());
        }
    }

    /**
     * Gère le clic sur une playlist
     * Sélectionne la playlist pour un évènement
     *
     * @param event évènement qui contient la playlist
     */
    @FXML
    public void onClicPlaylist(Event event) {
        playlist1.setStyle("-fx-background-color: #d5e7f7; -fx-border-color: #2c88d9;");
        playlist2.setStyle("-fx-background-color: #d5e7f7; -fx-border-color: #2c88d9;");
        playlist3.setStyle("-fx-background-color: #d5e7f7; -fx-border-color: #2c88d9;");
        playlist4.setStyle("-fx-background-color: #d5e7f7; -fx-border-color: #2c88d9;");
        if (playlist1.isFocused()) {
            playlist1.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p1.get(0).getNom() + ", " + p1.get(0).getArtiste());
            musique2.setText(p1.get(1).getNom() + ", " + p1.get(1).getArtiste());
            musique3.setText(p1.get(2).getNom() + ", " + p1.get(2).getArtiste());
            musique4.setText(p1.get(3).getNom() + ", " + p1.get(3).getArtiste());
            musique5.setText(p1.get(4).getNom() + ", " + p1.get(4).getArtiste());
            if (evenement != null) {
                evenement.setNumPlaylist(1);
            } else if (seminaire != null) {
                seminaire.setNumPlaylist(1);
            }
        } else if (playlist2.isFocused()) {
            playlist2.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p2.get(0).getNom() + ", " + p2.get(0).getArtiste());
            musique2.setText(p2.get(1).getNom() + ", " + p2.get(1).getArtiste());
            musique3.setText(p2.get(2).getNom() + ", " + p2.get(2).getArtiste());
            musique4.setText(p2.get(3).getNom() + ", " + p2.get(3).getArtiste());
            musique5.setText(p2.get(4).getNom() + ", " + p2.get(4).getArtiste());
            if (evenement != null) {
                evenement.setNumPlaylist(2);
            } else if (seminaire != null) {
                seminaire.setNumPlaylist(2);
            }
        } else if (playlist3.isFocused()) {
            playlist3.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p3.get(0).getNom() + ", " + p3.get(0).getArtiste());
            musique2.setText(p3.get(1).getNom() + ", " + p3.get(1).getArtiste());
            musique3.setText(p3.get(2).getNom() + ", " + p3.get(2).getArtiste());
            musique4.setText(p3.get(3).getNom() + ", " + p3.get(3).getArtiste());
            musique5.setText(p3.get(4).getNom() + ", " + p3.get(4).getArtiste());
            if (evenement != null) {
                evenement.setNumPlaylist(3);
            } else if (seminaire != null) {
                seminaire.setNumPlaylist(3);
            }
        } else {
            playlist4.setStyle("-fx-background-color: #ffde9b; -fx-border-color: #ffad05;");
            musique1.setText(p4.get(0).getNom() + ", " + p4.get(0).getArtiste());
            musique2.setText(p4.get(1).getNom() + ", " + p4.get(1).getArtiste());
            musique3.setText(p4.get(2).getNom() + ", " + p4.get(2).getArtiste());
            musique4.setText(p4.get(3).getNom() + ", " + p4.get(3).getArtiste());
            musique5.setText(p4.get(4).getNom() + ", " + p4.get(4).getArtiste());
            if (evenement != null) {
                evenement.setNumPlaylist(4);
            } else if (seminaire != null) {
                seminaire.setNumPlaylist(4);
            }
        }
    }

    // --------------------- Commun -------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
        ControleurAccueil controleurAccueil = new ControleurAccueil(genEvent);
        fxmlLoader.setController(controleurAccueil);
        Parent parent = fxmlLoader.load();
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
        fxmlLoader.setController(new ControleurSettings(genEvent));
        Parent parent = fxmlLoader.load();
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        fxmlLoader.setController(controleurArchive);
        Parent parent = fxmlLoader.load();
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives(); // Initialise les données des archives après chargement de la vue
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition des évènements
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void back(ActionEvent event) throws IOException {
        if (seminaire != null) {
            ModifyEventControleur modifyEventControleur2 = new ModifyEventControleur(genEvent, null, seminaire);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
            fxmlLoader.setController(modifyEventControleur2);
            Parent parent = fxmlLoader.load();
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur2.initializeModify();
        } else {
            ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
            fxmlLoader.setController(modifyEventControleur);
            Parent parent = fxmlLoader.load();
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur.initializeModify();
        }
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition pour les évènements classés dans les archives
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void backArchives(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-event-view.fxml"));
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
        fxmlLoader.setController(modifyEventControleur);
        Parent parent = fxmlLoader.load();
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        modifyEventControleur.initializeModify();
    }
}
