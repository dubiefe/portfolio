package fr.uga.iut2.genevent.modele;

import java.io.Serializable;

public class Nourriture implements Serializable {


    private String nom;
    private double prix;
    private int quantite;
    private boolean vegan;
    private boolean vegetarien;
    private boolean alcool;



    /**
     * Construit un objet de type nourriture avec un nom, un prix, une quantite et ses propriétés
     * @param nom nom de la nourriture
     * @param prix prix de la nourriture
     * @param quantite quantité voulue
     * @param vegan indique si le produit est végan ou non
     * @param vegetarien indique si le produit est végétarien ou non
     * @param alcool indique si le produit contient de l'alcool ou non
     */
    public Nourriture(String nom, double prix, int quantite, boolean vegan, boolean vegetarien, boolean alcool){
        this.nom = nom;
        this.prix = prix;
        this.quantite = quantite;
        this.vegan = vegan;
        this.vegetarien = vegetarien;
        this.alcool = alcool;
    }



    /**
     * Permet d'accéder au nom de la nourriture
     * @return le nom
     */
    public String getNom(){
        return nom;
    }

    /**
     * Permet d'accéder au prix de la nourriture selon la quantité
     * @return le prix
     */
    public double getPrix() {
        return prix*quantite;
    }

    /**
     * Permet d'accéder au prix à l'unité de la nourriture
     *
     * @return le prix à l'unité
     */
    public double getPrixUnite() {
        return prix;
    }

    /**
     * Permet d'accéder à la quantité du produit voulu
     * @return la quantité
     */
    public int getQuantite(){
        return quantite;
    }

    /**
     * Indique si la nourriture est végan
     * @return vrai si le produit est végan, faux si non
     */
    public boolean isVegan() {
        return vegan;
    }

    /**
     * Indique si la nourriture est appropriée pour les végétariens ou non
     * @return vrai si le produit est adapté aux végétariens, faux si non
     */
    public boolean isVegetarien() {
        return vegetarien;
    }

    /**
     * Indique si la nourriture contient de l'alcool ou non
     * @return vrai si le produit contient de l'alcool, faux si non
     */
    public boolean isAlcool() {
        return alcool;
    }


    /**
     * Modifie le nom de la nourriture
     * @param nom nouveau nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Modifie le prix de la nourriture
     * @param prix nouveau prix
     */
    public void setPrix(double prix){
        this.prix = prix;
    }

    /**
     * Modifie la quantité voulue du produit
     * @param quantite quantité voulue
     */
    public void setQuantite(int quantite){
        this.quantite = quantite;
    }

    /**
     * Modifie la propriété végan de la nourriture
     * @param vegan vrai si végan, faux si non
     */
    public void setVegan(boolean vegan) {
        this.vegan = vegan;
    }

    /**
     * Modifie la propriété végétarienne de la nourriture
     * @param vegetarien vrai si végétarien, faux si non
     */
    public void setVegetarien(boolean vegetarien) {
        this.vegetarien = vegetarien;
    }

    /**
     * Modifie la propriété de l'alcool de la nourriture
     * @param alcool vrai s'il y a de l'alcool, faux si non
     */
    public void setAlcool(boolean alcool) {
        this.alcool = alcool;
    }


}
