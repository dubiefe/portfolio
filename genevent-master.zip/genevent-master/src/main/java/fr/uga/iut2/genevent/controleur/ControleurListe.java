package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.Evenement;
import fr.uga.iut2.genevent.modele.ExceptionInterface;
import fr.uga.iut2.genevent.modele.GenEvent;
import fr.uga.iut2.genevent.modele.Seminaire;
import fr.uga.iut2.genevent.modele.TypeEvenement;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import java.time.LocalDate;
import java.util.logging.Logger;

public class ControleurListe {

    //Attributs
    private final GenEvent genEvent;
    private TypeEvenement typeEvenement;
    public static final Logger LOGGER = Logger.getLogger(ControleurListe.class.getName());
    @FXML public ComboBox<String> txtLieu;
    @FXML private Label txtType, type;
    @FXML private Button creer;
    @FXML private VBox listeEvent = new VBox();

    //Constructeur
    public ControleurListe(GenEvent genEvent) {
        this.genEvent = genEvent;
        initialize();
    }

    //Méthodes

    /**
     * Attribut un type à un évènement selon un label
     * @param type1  label, nom du type
     */
    public void setType(Label type1) {
        type.setText(type1.getText());
    }

    /**
     * Permet le transfert de type entre les fonctions
     * @param typeEvenement type à transférer
     */
    public void setTypeEvenement(TypeEvenement typeEvenement) {
        this.typeEvenement = typeEvenement;
    }

    /**
     *Affiche un pop up pour créer un évènement
     *
     * @param event l'évènement de clic sur le bouton '+'
     * @throws IOException si le fichier FXML ne peut pas charger
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    public void createEventPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Bouton créee un évènement click");
        Parent parent;
        Scene scenePrincipal = creer.getScene();
        Stage stagePrincipal = (Stage) scenePrincipal.getWindow();
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, stagePrincipal, null);
        FXMLLoader fxmlLoader;
        if (type.getText().equals("Seminar")) {
            fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/create-seminar-view.fxml"));
        } else {
            fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/create-event-view.fxml"));
        }
        fxmlLoader.setController(modifyEventControleur);
        parent = fxmlLoader.load();
        Stage stage = new Stage();
        Label label = new Label(type.getText());
        Scene scene = new Scene(parent, 400, 400);
        stage.setScene(scene);
        stage.show();
        modifyEventControleur.setTxtType(label);
        LOGGER.info("affichage popup pour crée un évènement");
        //Attribution des lieux selon le type d'évènement
        if(modifyEventControleur.getTxtType().equals("Integration party") || modifyEventControleur.getTxtType().equals("Leaving party")) {
            modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Corporation","Private room","Bar"));
        }else if(modifyEventControleur.getTxtType().equals("Conference")) {
            modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Corporation","Theater","Conference center"));
        }else if(modifyEventControleur.getTxtType().equals("Seminar")) {
            modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Hotel with a conference room","Coworking space","Cultural Center"));
        }else if(modifyEventControleur.getTxtType().equals("Team-building")){
            modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Laser Game","Paint Ball","Hiking","Adventure park"));
        }else{
            modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Bars","Pubs","Rooftop","Restaurant","Terrace"));
        }
    }

    /**
     * Initialise la liste des évènement d'un type choisi précédemment
     * Ajoute les conteneurs et le style nécessaire
     */
    public void initialize() {
        LOGGER.info("chargement affichage des évènements type: "+typeEvenement);
        for (Evenement evenement : genEvent.getListe(typeEvenement)) {
            if (evenement.getDate().isAfter(LocalDate.now())) {
                HBox hBoxEvenement = new HBox();
                Button button = new Button();
                Button duplicate = new Button("Duplicate");
                Label label = new Label();
                listeEvent.getChildren().add(hBoxEvenement);
                button.setText(evenement.getNom());
                label.setText("on " + evenement.getDate() + " at " + evenement.getLieu());
                button.setGraphic(label);
                button.contentDisplayProperty().set(ContentDisplay.BOTTOM);
                hBoxEvenement.getChildren().add(button);
                hBoxEvenement.getChildren().add(duplicate);
                button.setStyle("-fx-background-color:#d5e7f7; -fx-border-color:#3498db; -fx-border-radius:10 0 0 10; -fx-border-width:2; -fx-pref-width:652; -fx-pref-height:100; -fx-alignment:center-left; ");
                duplicate.setStyle("-fx-background-color:gray; -fx-border-radius:10; -fx-border-width:2; -fx-pref-width:100; -fx-pref-height:100; -fx-text-fill:white;");
                button.setUserData(evenement);
                button.setOnAction(e -> {
                    try {
                        modifEvent(e);
                    } catch (IOException | ExceptionInterface ex) {
                        throw new RuntimeException(ex);
                    }
                });
                duplicate.setOnAction(this::duplicate);
                duplicate.setUserData(evenement);
            }
        }
        LOGGER.info("chargement affichage des évènements type ("+typeEvenement+") réussi ");
    }

    /**
     * Redirige vers la page de modification de l'évènement
     *
     * @param actionEvent l'événement clic sur le bouton pour éditer l'évènement
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    public void modifEvent(ActionEvent actionEvent) throws IOException, ExceptionInterface {
        Node node = (Node) actionEvent.getSource();
        Evenement evenement = (Evenement) node.getUserData();

        LOGGER.info("chargement de l'interface pour modifier l'évènement de nom: " + evenement.getNom());
        Stage stage = (Stage) node.getScene().getWindow();
        Label label = new Label(type.getText());

        FXMLLoader fxmlLoader;
        //Pour séminaire
        if (evenement.getType().equals(TypeEvenement.SEMINAIRE)) {
            Seminaire seminaire = (Seminaire) node.getUserData();
            ModifyEventControleur modifyEventControleur2 = new ModifyEventControleur(genEvent, null, seminaire);
            fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
            fxmlLoader.setController(modifyEventControleur2);
            Parent parent = fxmlLoader.load();
            Scene scene = new Scene(parent, 1000, 600);
            stage.setScene(scene);
            stage.show();
            modifyEventControleur2.setTxtType(label);
            modifyEventControleur2.initializeModify();
            modifyEventControleur2.getTxtLieu().setItems(FXCollections.observableArrayList("Hotel with a conference room", "Coworking space", "Cultural Center"));
        }
        //Pour les autres types d'évènement
        else {
            ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
            fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
            fxmlLoader.setController(modifyEventControleur);
            Parent parent = fxmlLoader.load();
            Scene scene = new Scene(parent, 1000, 600);
            stage.setScene(scene);
            stage.show();
            modifyEventControleur.setTxtType(label);
            modifyEventControleur.initializeModify();
            if (modifyEventControleur.getTxtType().equals("Integration party") || modifyEventControleur.getTxtType().equals("Leaving party")) {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Corporation", "private room", "Bar"));
            } else if (modifyEventControleur.getTxtType().equals("Conference")) {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Corporation", "Theater", "Conference center"));
            } else {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Laser Game", "Paint Ball", "Hiking", "Adventure park"));
            }
            modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
            try {
                fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
                fxmlLoader.setController(modifyEventControleur);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            scene = new Scene(parent, 1000, 600);
            stage.setScene(scene);
            stage.show();
            modifyEventControleur.setTxtType(label);
            modifyEventControleur.initializeModify();
            //Attribution des lieux
            if (modifyEventControleur.getTxtType().equals("Integration party") || modifyEventControleur.getTxtType().equals("Leaving party")) {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Corporation", "private room", "Bar"));
            } else if (modifyEventControleur.getTxtType().equals("Conference")) {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Corporation", "Theater", "Conference center"));
            } else if (modifyEventControleur.getTxtType().equals("Seminar")) {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Hotel with a conference room", "Coworking space", "Cultural Center"));
            } else if (modifyEventControleur.getTxtType().equals("Team-building")) {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Laser Game", "Paint Ball", "Hiking", "Adventure park"));
            } else {
                modifyEventControleur.getTxtLieu().setItems(FXCollections.observableArrayList("Bars", "Pubs", "Rooftop", "Restaurant", "Terrace"));
            }
            LOGGER.info("chargement de l'interface pour modifier l'évènement de nom: " + evenement.getNom() + " réussi");
        }
    }

    /**
     * Duplique l'évènement sélectionné et les attributs qui vont avec
     * Affiche le nouvel évènement (copy) dans la liste d'évènements
     *
     * @param event l'événement clic sur le bouton 'Duplicate'
     */
    public void duplicate (ActionEvent event){
        Node node = (Node) event.getSource();
        Evenement evenement = (Evenement) node.getUserData();
        LOGGER.info("bouton duplicate de l'évènement de nom: ("+evenement.getNom()+") click");
        if (evenement.getType().equals(TypeEvenement.SEMINAIRE)) {
            Seminaire seminaire = (Seminaire) node.getUserData();
            Seminaire newSeminaire = (Seminaire) seminaire.dupliquer();
            boolean nameUnique = false;
            for (int i = 0; i < genEvent.getEvenements().size(); i++) {
                if (newSeminaire.getNom().equals(genEvent.getEvenements().get(i).getNom())) {
                    nameUnique = true;
                    break;
                }
            }
            while (nameUnique) {
                nameUnique = false;
                newSeminaire.setNom(newSeminaire.getNom() + " (copie)");
                for (int i = 0; i < genEvent.getEvenements().size(); i++) {
                    if (newSeminaire.getNom().equals(genEvent.getEvenements().get(i).getNom())) {
                        nameUnique = true;
                        break;
                    }
                }
            }
            genEvent.addEvent(newSeminaire);
            HBox hBox = new HBox();
            Button button = new Button();
            Button duplicate = new Button("Duplicate");
            Label label = new Label();
            listeEvent.getChildren().add(hBox);
            button.setText(newSeminaire.getNom());
            label.setText("on " + seminaire.getDate() + " at " + seminaire.getLieu());
            button.setGraphic(label);
            button.contentDisplayProperty().set(ContentDisplay.BOTTOM);
            hBox.getChildren().add(button);
            hBox.getChildren().add(duplicate);
            button.setStyle("-fx-background-color:#d5e7f7; -fx-border-color:#3498db; -fx-border-radius:10 0 0 10; -fx-border-width:2; -fx-pref-width:652; -fx-pref-height:100; -fx-alignment:center-left; ");
            duplicate.setStyle("-fx-background-color:gray; -fx-border-radius:10; -fx-border-width:2; -fx-pref-width:100; -fx-pref-height:100; -fx-text-fill:white;");
            button.setUserData(newSeminaire);
            button.setOnAction(e -> {
                try {
                    modifEvent(e);
                } catch (IOException | ExceptionInterface ex) {
                    throw new RuntimeException(ex);
                }
            });
            duplicate.setOnAction(this::duplicate);
            duplicate.setUserData(newSeminaire);
            LOGGER.info("copie de l'évènement de nom: (" + seminaire.getNom() + ") reussi");
        } else {
            Evenement newEvenement = evenement.dupliquer();
            boolean nameUnique = false;
            for (int i = 0; i < genEvent.getEvenements().size(); i++) {
                if (newEvenement.getNom().equals(genEvent.getEvenements().get(i).getNom())) {
                    nameUnique = true;
                    break;
                }
            }
            while (nameUnique) {
                nameUnique = false;
                newEvenement.setNom(newEvenement.getNom() + " (copie)");
                for (int i = 0; i < genEvent.getEvenements().size(); i++) {
                    if (newEvenement.getNom().equals(genEvent.getEvenements().get(i).getNom())) {
                        nameUnique = true;
                        break;
                    }
                }
            }
            genEvent.addEvent(newEvenement);
            HBox hBox = new HBox();
            Button button = new Button();
            Button duplicate = new Button("Duplicate");
            Label label = new Label();
            listeEvent.getChildren().add(hBox);
            button.setText(newEvenement.getNom());
            label.setText("on " + evenement.getDate() + " at " + evenement.getLieu());
            button.setGraphic(label);
            button.contentDisplayProperty().set(ContentDisplay.BOTTOM);
            hBox.getChildren().add(button);
            hBox.getChildren().add(duplicate);
            button.setStyle("-fx-background-color:#d5e7f7; -fx-border-color:#3498db; -fx-border-radius:10 0 0 10; -fx-border-width:2; -fx-pref-width:652; -fx-pref-height:100; -fx-alignment:center-left; ");
            duplicate.setStyle("-fx-background-color:gray; -fx-border-radius:10; -fx-border-width:2; -fx-pref-width:100; -fx-pref-height:100; -fx-text-fill:white;");
            button.setUserData(newEvenement);
            button.setOnAction(e -> {
                try {
                    modifEvent(e);
                } catch (IOException | ExceptionInterface ex) {
                    throw new RuntimeException(ex);
                }
            });
            duplicate.setOnAction(this::duplicate);
            duplicate.setUserData(newEvenement);
            LOGGER.info("copie de l'évènement de nom: (" + evenement.getNom() + ") reussi");
        }
    }

    // ------------------------------------- Commun -------------------------------------
    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface setting réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }



}
