package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.logging.Logger;
import java.util.regex.Pattern;

public class ControleurNewAndDelete {

    //Attributs
    private GenEvent genEvent;
    private Evenement evenement;
    public static final Logger LOGGER = Logger.getLogger(ControleurNewAndDelete.class.getName());
    private Seminaire seminaire;
    private Stage stage;
    @FXML private TextField nomMatos, prixMatos, quantMatos;
    @FXML private TextField nomInvite, emailInvite;
    @FXML private TextField nomHotel, prixHotel;

    //Constructeurs
    public ControleurNewAndDelete(GenEvent genEvent, Stage stage, Evenement evenement) {
        this.genEvent = genEvent;
        this.evenement = evenement;
        this.stage = stage;
    }

    public ControleurNewAndDelete(GenEvent genEvent, Stage stage, Seminaire seminaire) {
        this.genEvent = genEvent;
        this.seminaire = seminaire;
        this.stage = stage;
    }

    //Méthodes
    /**
     * Ferme la fenêtre du pop up et retourne sur la page principale
     *
     * @param event l'événement clic sur le bouton 'Cancel'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void cancel(ActionEvent event) throws IOException {
        Scene scene = ((Node) event.getSource()).getScene();
        Stage stage = (Stage) scene.getWindow();
        stage.close();
        LOGGER.info("fermeture du popup");
    }


    /**
     * Supprime l'événement sélectionné
     *
     * @param event l'événement clic sur le bouton delete
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteEvent(ActionEvent event) throws IOException, ExceptionInterface {
        if (evenement != null) {
            LOGGER.info("suppresion de l'évènement de nom: ("+evenement.getNom()+") en cours");
            genEvent.getEvenements().remove(evenement);
            Node node = (Node) event.getSource();
            Scene scene = node.getScene();
            Stage stage = (Stage) scene.getWindow();
            stage.close();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            ControleurListe controleurListe = new ControleurListe(genEvent);
            try {
                fxmlLoader.setController(controleurListe);
                Scene newScene = new Scene(fxmlLoader.load(), 1000, 600);
                this.stage.setScene(newScene);
                this.stage.show();
            }catch (IOException e){
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            if (evenement.getType().equals(TypeEvenement.POT_DE_DEPART)) {
                controleurListe.setType(new Label("Leaving party"));
                genEvent.getListe(TypeEvenement.POT_DE_DEPART).remove(evenement);
            } else if (evenement.getType().equals(TypeEvenement.SOIREE_DINTEGRATION)) {
                controleurListe.setType(new Label("Integration party"));
                genEvent.getListe(TypeEvenement.SOIREE_DINTEGRATION).remove(evenement);
            } else if (evenement.getType().equals(TypeEvenement.CONFERENCE)) {
                controleurListe.setType(new Label("Conference"));
                genEvent.getListe(TypeEvenement.CONFERENCE).remove(evenement);
            } else if (evenement.getType().equals(TypeEvenement.TEAMBUILDING)) {
                controleurListe.setType(new Label("Team Building"));
                genEvent.getListe(TypeEvenement.TEAMBUILDING).remove(evenement);
            } else {
                controleurListe.setType(new Label("Afterwork Party"));
                genEvent.getListe(TypeEvenement.SOIREE_AFTERWORK).remove(evenement);
            }
            controleurListe.setTypeEvenement(evenement.getType());
            controleurListe.initialize();
            LOGGER.info("suppresion de l'évènement de nom: ("+evenement.getNom()+") réussi");
        } else if (seminaire != null) {
            LOGGER.info("suppresion d'un séminaire de nom: ("+seminaire.getNom()+") en cours");
            genEvent.getEvenements().remove(seminaire);
            Node node = (Node) event.getSource();
            Scene scene = node.getScene();
            Stage stage = (Stage) scene.getWindow();
            stage.close();
            FXMLLoader fxmlLoader2 = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            ControleurListe controleurListe = new ControleurListe(genEvent);
            try {
                fxmlLoader2.setController(controleurListe);
                Scene newScene = new Scene(fxmlLoader2.load(), 1000, 600);
                this.stage.setScene(newScene);
                this.stage.show();
            }catch (IOException e){
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            controleurListe.setType(new Label("Seminar"));
            genEvent.getListe(TypeEvenement.SEMINAIRE).remove(seminaire);
            controleurListe.setTypeEvenement(seminaire.getType());
            controleurListe.initialize();
            LOGGER.info("suppresion d'un séminaire de nom: ("+seminaire.getNom()+") réussi");
        }
    }

    /* --------------------------------------- Invités --------------------------------------- */
    /**
     * Ajoute un nouvel invité  à un évènement
     *
     * @param event l'événement clic sur le bouton 'Create'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void createGuest(ActionEvent event) throws IOException, ExceptionInterface {
        if (!nomInvite.getText().isEmpty() & !emailInvite.getText().isEmpty() && isEmailValid(emailInvite.getText())) {
            LOGGER.info("ajout d'un invité de nom: ("+nomInvite.getText()+") en cours");
            if (evenement != null) {
                evenement.getInvites().add(new Invite(nomInvite.getText(), emailInvite.getText()));
            } else if (seminaire != null) {
                seminaire.getInvites().add(new Invite(nomInvite.getText(), emailInvite.getText()));
            }
            Scene scene = ((Node) event.getSource()).getScene();
            Stage stagePopup = (Stage) scene.getWindow();
            stagePopup.close();
            stage.close();
            Parent parent;
            if (evenement != null) {
                ControleurGuest controleurGuest = new ControleurGuest(genEvent, evenement);
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/guest-view.fxml"));
                    loader.setController(controleurGuest);
                    parent = loader.load();
                } catch (IOException e) {
                    throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
                }
                stage.getScene().setRoot(parent);
                stage.show();
                controleurGuest.initializeInvite();
                LOGGER.info("ajout du nouvel invité réussi");
            } else if (seminaire != null) {
                ControleurGuest controleurGuest = new ControleurGuest(genEvent, seminaire);
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/guest-view.fxml"));
                    loader.setController(controleurGuest);
                    parent = loader.load();
                } catch (IOException e) {
                    throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
                }
                stage.getScene().setRoot(parent);
                stage.show();
                controleurGuest.initializeInvite();
                LOGGER.info("ajout du nouvel invité réussi");
            }
        } else {
            if (nomInvite.getText().isEmpty()) {
                nomInvite.setStyle("-fx-border-color: red");
                nomInvite.setPromptText("The name must not be empty");
            } else {
                nomInvite.setStyle("-fx-border-color: black");
            }
            if (emailInvite.getText().isEmpty()) {
                emailInvite.setStyle("-fx-border-color: red");
                emailInvite.setPromptText("The email must not be empty");
            } else if (!isEmailValid(emailInvite.getText())) {
                emailInvite.setStyle("-fx-border-color: red");
                emailInvite.clear();
                emailInvite.setPromptText("Enter a valid email");
            } else {
                emailInvite.setStyle("-fx-border-color: black");
            }
        }
    }

    /**
     * Supprime l'invité sélectionné de la liste des invités de l'évènement
     *
     * @param event l'événement clic sur le bouton 'delete'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteGuest(ActionEvent event) throws IOException, ExceptionInterface {
        Invite invite = (Invite) this.stage.getUserData();
        LOGGER.info("suppresion de l'invité de nom: ("+invite.getNom()+") en cours");
        if (evenement != null) {
            evenement.removeInvite(invite);
            ControleurGuest controleurFGPBM = new ControleurGuest(genEvent, evenement);
            Parent parent;
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/guest-view.fxml"));
                loader.setController(controleurFGPBM);
                parent = loader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            stage.getScene().setRoot(parent);
            Scene scene = ((Node) event.getSource()).getScene();
            Stage stagePopup = (Stage) scene.getWindow();
            stagePopup.close();
            stage.getScene().getWindow();
            controleurFGPBM.initializeInvite();
        } else if (seminaire != null) {
            seminaire.removeInvite(invite);
            ControleurGuest controleurFGPBM = new ControleurGuest(genEvent, seminaire);
            Parent parent;
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/guest-view.fxml"));
                loader.setController(controleurFGPBM);
                parent = loader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            stage.getScene().setRoot(parent);
            Scene scene = ((Node) event.getSource()).getScene();
            Stage stagePopup = (Stage) scene.getWindow();
            stagePopup.close();
            stage.getScene().getWindow();
            controleurFGPBM.initializeInvite();
        }
        LOGGER.info("suppresion de l'invité de nom: ("+invite.getNom()+") réussi");
    }

    /* --------------------------------------- Matériel --------------------------------------- */
    /**
     * Ajoute un matériel à un évènement si le budget le permet
     *
     * @param event l'événement clic sur le bouton 'Create'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void createMaterial(ActionEvent event) throws IOException, ExceptionInterface {
        if (!nomMatos.getText().isEmpty() & !prixMatos.getText().isEmpty() & isDouble(prixMatos.getText()) & !quantMatos.getText().isEmpty() & isInt(quantMatos.getText())) {
            LOGGER.info("ajout du materiel de nom: ("+nomMatos.getText()+") en cours");
            if (evenement != null) {
                evenement.addMateriel(new Materiel(nomMatos.getText(), Double.parseDouble(prixMatos.getText()), Integer.parseInt(quantMatos.getText())));
            } else if (seminaire != null) {
                seminaire.addMateriel(new Materiel(nomMatos.getText(), Double.parseDouble(prixMatos.getText()), Integer.parseInt(quantMatos.getText())));
            }
            Scene scene = ((Node) event.getSource()).getScene();
            Stage stagePopup = (Stage) scene.getWindow();
            stagePopup.close();
            stage.close();
            Parent parent;
            if (evenement != null) {
                ControleurMaterial controleurFGPBM = new ControleurMaterial(genEvent, evenement);
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/material-view.fxml"));
                    loader.setController(controleurFGPBM);
                    parent = loader.load();
                } catch (IOException e) {
                    throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
                }
                stage.getScene().setRoot(parent);
                stage.show();
                controleurFGPBM.initializeMaterial();
                LOGGER.info("ajout du nouveau materiel réussi");
            } else if (seminaire != null) {
                ControleurMaterial controleurFGPBM = new ControleurMaterial(genEvent, seminaire);
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/material-view.fxml"));
                    loader.setController(controleurFGPBM);
                    parent = loader.load();
                } catch (IOException e) {
                    throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
                }
                stage.getScene().setRoot(parent);
                stage.show();
                controleurFGPBM.initializeMaterial();
                LOGGER.info("ajout du nouveau materiel réussi");
            }
        } else {
            if (nomMatos.getText().isEmpty()) {
                nomMatos.setStyle("-fx-border-color: red");
                nomMatos.setPromptText("The name must not be empty");
            } else {
                nomMatos.setStyle("-fx-border-color: black");
            }
            if (prixMatos.getText().isEmpty()) {
                prixMatos.setStyle("-fx-border-color: red");
                prixMatos.setPromptText("The price must not be empty");
            } else if (!isDouble(prixMatos.getText())) {
                prixMatos.setStyle("-fx-border-color: red");
                prixMatos.clear();
                prixMatos.setPromptText("The price must be a number");
            } else {
                prixMatos.setStyle("-fx-border-color: black");
            }
            if (quantMatos.getText().isEmpty()) {
                quantMatos.setStyle("-fx-border-color: red");
                quantMatos.setPromptText("The quantity must not be empty");
            } else if (!isInt(quantMatos.getText())) {
                quantMatos.setStyle("-fx-border-color: red");
                quantMatos.clear();
                quantMatos.setPromptText("The quantity must be a number");
            } else {
                quantMatos.setStyle("-fx-border-color: black");
            }
        }
    }

    /**
     * Supprime le matériel sélectionné de l'événement.
     *
     * @param event l'événement clic sur le bouton 'delete'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteMaterial(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("suppresion d'un materiel en cours");
        Materiel matos = (Materiel) this.stage.getUserData();
        if (evenement != null) {
            evenement.removeMateriel(matos);
        } else if (seminaire != null) {
            seminaire.removeMateriel(matos);
        }
        Parent parent;
        if (evenement != null) {
            ControleurMaterial controleurFGPBM = new ControleurMaterial(genEvent, evenement);
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/material-view.fxml"));
                loader.setController(controleurFGPBM);
                parent = loader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            stage.getScene().setRoot(parent);
            Scene scene = ((Node) event.getSource()).getScene();
            Stage stagePopup = (Stage) scene.getWindow();
            stagePopup.close();
            stage.getScene().getWindow();
            controleurFGPBM.initializeMaterial();
            LOGGER.info("suppresion d'un materiel réussi");
        } else if (seminaire != null) {
            ControleurMaterial controleurFGPBM = new ControleurMaterial(genEvent, seminaire);
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/material-view.fxml"));
                loader.setController(controleurFGPBM);
                parent = loader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            stage.getScene().setRoot(parent);
            Scene scene = ((Node) event.getSource()).getScene();
            Stage stagePopup = (Stage) scene.getWindow();
            stagePopup.close();
            stage.getScene().getWindow();
            controleurFGPBM.initializeMaterial();
            LOGGER.info("suppresion d'un materiel réussi");
        }
    }

    /* --------------------------------------- Hotel --------------------------------------- */

    /**
     * Ajoute un hotel à un séminaire
     *
     * @param event l'évènement clic sur le bouton 'Create'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void createHotel(ActionEvent event) throws IOException {
            seminaire.setHotel(new Hotel(nomHotel.getText(), Double.parseDouble(prixHotel.getText())));
        Scene scene = ((Node) event.getSource()).getScene();
        Stage stagePopup = (Stage) scene.getWindow();
        stagePopup.close();
        stage.close();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/hotel-view.fxml"));
        ControleurHotel controleurFGPBM = new ControleurHotel(genEvent, seminaire);
        loader.setController(controleurFGPBM);
        Parent parent = loader.load();
        stage.getScene().setRoot(parent);
        stage.show();
        controleurFGPBM.initializeHotel();
    }

    /**
     * Supprime un hotel pour un séminaire
     *
     * @param event l'évènement de clic sur le bouton 'delete'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteHotel(ActionEvent event) throws IOException {
        Hotel hotel = (Hotel) this.stage.getUserData();
        seminaire.setHotel(null);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/hotel-view.fxml"));
        ControleurHotel controleurFGPBM = new ControleurHotel(genEvent, seminaire);
        loader.setController(controleurFGPBM);
        Parent parent = loader.load();
        stage.getScene().setRoot(parent);
        Scene scene = ((Node) event.getSource()).getScene();
        Stage stagePopup = (Stage) scene.getWindow();
        stagePopup.close();
        stage.getScene().getWindow();
        controleurFGPBM.initializeHotel();
    }

    /**
     * Supprime l'événement sélectionné de la liste des archives
     *
     * @param event l'événement clic sur le bouton 'delete'
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteEventArchives(ActionEvent event) throws IOException {
        genEvent.getEvenements().remove(evenement);
        Node node = (Node) event.getSource();
        Scene scene = node.getScene();
        Stage stage = (Stage) scene.getWindow();
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        fxmlLoader.setController(controleurArchive);
        Scene newScene = new Scene(fxmlLoader.load(), 1000, 600);
        this.stage.setScene(newScene);
        this.stage.show();
        controleurArchive.initializeArchives();
    }

    // --------------------------- Détection des erreurs ---------------------------

    /**
     * Permet de savoir si une chaîne est sous forme d'email ou non
     * @param email chaîne à tester
     * @return Vrai si la forme est correcte, faux si non
     */
    public static boolean isEmailValid(String email) {
        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailPattern);
        return pat.matcher(email).matches();
    }

    /**
     * Permet de savoir si une chaîne est sous forme de double ou non
     * @param strNum chaîne à tester
     * @return Vrai si la chaîne est un double, faux si non
     */
    public static boolean isDouble(String strNum) {
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * Permet de savoir si une chaîne est sous forme d'entie ou non
     * @param strNum chaîne à tester
     * @return Vrai si la chaîne est un entier, faux si non
     */
    public static boolean isInt(String strNum) {
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
}
