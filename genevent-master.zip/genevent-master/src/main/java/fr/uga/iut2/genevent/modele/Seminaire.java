package fr.uga.iut2.genevent.modele;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class Seminaire extends Evenement implements Serializable {

    private LocalDate dateFin;
    private Hotel hotel;

    /**
     * Constructeur Seminaire avec comme paramètres le nom, lieu, date début, type évènement, l'entreprise et la date fin du séminaire
     * @param nom le nom du séminaire
     * @param lieu le lieu du séminaire
     * @param dateDebut la date de début du séminaire
     * @param type le type d'évènement (ici séminaire)
     * @param  budget l'entreprise qui propose le séminaire
     * @param dateFin la date fin du séminaire
     */
    public Seminaire(String nom, String lieu, LocalDate dateDebut, TypeEvenement type, Double budget, LocalDate dateFin) {
        super(nom, lieu, dateDebut,TypeEvenement.SEMINAIRE, budget);
        setDateFin(dateFin);
    }


    /**
     * Permet d'acceder à l'hotel du séminaire
     * @return l'hotel du séminaire
     */
    public Hotel getHotel() {
        return hotel;
    }

    /**
     * Permet d'attribuer un hotel pour le séminaire
     * @param hotel l'hotel du séminaire
     */
    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    /**
     * Permet d'accéder à la date de fin du séminaire
     * @return la date de fin du séminaire
     */
    public LocalDate getDateFin() {
        return dateFin;
    }

    /**
     * Permet d'attribuer une date de fin au séminaire
     * @param dateFin la date de fin du séminaire
     */
    public void setDateFin(LocalDate dateFin) {
        this.dateFin = dateFin;
    }

    @Override
    public Evenement dupliquer() {
        Seminaire newSeminaire = new Seminaire(super.getNom() + " (copie)", super.getLieu(), super.getDate(), super.getType(), super.getBudget(), dateFin);
        newSeminaire.setNumPlaylist(super.getNumPlaylist());
        for(Nourriture nourriture : super.getMenu()) {
            newSeminaire.addNourriture(nourriture);
        }
        for (Invite invite : super.getInvites()) {
            newSeminaire.addInvite(invite);
        }
        for (Materiel materiel : super.getMateriels()) {
            newSeminaire.addMateriel(materiel);
        }
        newSeminaire.setHotel(hotel);
        return newSeminaire;
    }

   @Override
    public double getBudgetCourrant() {
        double budget = super.getBudget();
        if (hotel != null) {
            budget = budget - super.getInvites().size() * getHotel().getPrixPersonne();
        }
        return budget;
    }
}
