package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.logging.Logger;

public class ControleurBudget {
    //Attributs
    private GenEvent genEvent;
    private Evenement evenement;
    private Seminaire seminaire;
    public static final Logger LOGGER = Logger.getLogger(ControleurAccueil.class.getName());
    @FXML private Text txtBudgetRestant, txtBudgetTot, txtBudgetSpent;
    @FXML private VBox vboxDepense;

    //Constructeurs
    public ControleurBudget(GenEvent genEvent, Evenement event) {
        this.genEvent = genEvent;
        this.evenement = event;
    }

    public ControleurBudget(GenEvent genEvent, Seminaire seminaire) {
        this.genEvent = genEvent;
        this.seminaire = seminaire;
    }

    //Méthodes

    /**
     * Initialise la page budget
     * Met à jour la liste des dépenses, le budget total, le budget dépensé et le budget restant
     */
    @FXML
    public void initializeBudget() {
        //Pour évènement
        if (evenement != null) {
            LOGGER.info("Chargement du budget pour l'évènement de nom: " + evenement.getNom() + " en cours");
            //Mise à jour du budget total, restant et dépensé
            txtBudgetTot.setText(Double.toString(evenement.getBudget()));
            txtBudgetRestant.setText(Double.toString(evenement.getBudgetCourrant()));
            txtBudgetSpent.setText(Double.toString(evenement.getBudget() - evenement.getBudgetCourrant()));

            //Ajout des dépenses de materiel
            for (Materiel materiel : evenement.getMateriels()) {
                //Création hbox principale
                HBox conteneur = new HBox();
                conteneur.setPrefSize(450.0, 50.0);
                conteneur.setMaxSize(450.0, 50.0);
                conteneur.setAlignment(Pos.CENTER_LEFT);
                conteneur.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10; -fx-padding:10");
                vboxDepense.getChildren().add(conteneur);

                //Elements hBox
                HBox nom = new HBox();
                nom.setPrefSize(200, 100);
                nom.setAlignment(Pos.CENTER_LEFT);
                HBox prix = new HBox();
                prix.setPrefSize(272, 100);
                prix.setAlignment(Pos.CENTER_RIGHT);
                conteneur.getChildren().add(nom);
                conteneur.getChildren().add(prix);

                //Textes
                Text nomMat = new Text(materiel.getNom());
                nomMat.setStyle("-fx-font-size:18; -fx-padding-left:20;");
                nom.getChildren().add(nomMat);
                Text prixMat = new Text(Double.toString(materiel.getPrix()));
                prixMat.setStyle("-fx-font-size:18; -fx-padding-right:20;");
                prix.getChildren().add(prixMat);
            }

            //Ajout des dépenses de nourriture
            for (Nourriture nourriture : evenement.getMenu()) {
                //Création hbox principale
                HBox conteneur2 = new HBox();
                conteneur2.setPrefSize(450.0, 50.0);
                conteneur2.setMaxSize(450.0, 50.0);
                conteneur2.setAlignment(Pos.CENTER_LEFT);
                conteneur2.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10; -fx-padding:10");
                vboxDepense.getChildren().add(conteneur2);

                //Elements hbox
                HBox nom = new HBox();
                nom.setPrefSize(200.0, 100.0);
                nom.setAlignment(Pos.CENTER_LEFT);
                HBox prix = new HBox();
                prix.setPrefSize(272.0, 100.0);
                prix.setAlignment(Pos.CENTER_RIGHT);
                conteneur2.getChildren().add(nom);
                conteneur2.getChildren().add(prix);

                //Textes
                Text nomFood = new Text(nourriture.getNom());
                nomFood.setStyle("-fx-font-size:18; -fx-padding-left:20;");
                nom.getChildren().add(nomFood);
                Text prixFood = new Text(Double.toString(nourriture.getPrix()));
                prixFood.setStyle("-fx-font-size:18; -fx-padding-right:20;");
                prix.getChildren().add(prixFood);
            }
            LOGGER.info("Chargement du budget pour l'évènement de nom: " + evenement.getNom() + " réussi");
        } else if (seminaire != null) {
            //Pour les séminaires
            LOGGER.info("Chargement du budget pour le séminaire de nom: " + seminaire.getNom() + " en cours");
            //mise à jour budget total, restant et dépensé
            txtBudgetTot.setText(Double.toString(seminaire.getBudget()));
            txtBudgetRestant.setText(Double.toString(seminaire.getBudgetCourrant()));
            txtBudgetSpent.setText(Double.toString(seminaire.getBudget() - seminaire.getBudgetCourrant()));

            //Ajout des dépenses de materiel
            for (Materiel materiel : seminaire.getMateriels()) {
                //Création hbox principale
                HBox conteneur = new HBox();
                conteneur.setPrefSize(450.0, 50.0);
                conteneur.setMaxSize(450.0, 50.0);
                conteneur.setAlignment(Pos.CENTER_LEFT);
                conteneur.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10; -fx-padding:10");
                vboxDepense.getChildren().add(conteneur);

                //Elements hbox
                HBox nom = new HBox();
                nom.setPrefSize(200, 100);
                nom.setAlignment(Pos.CENTER_LEFT);
                HBox prix = new HBox();
                prix.setPrefSize(272, 100);
                prix.setAlignment(Pos.CENTER_RIGHT);
                conteneur.getChildren().add(nom);
                conteneur.getChildren().add(prix);

                //Textes
                Text nomMat = new Text(materiel.getNom());
                nomMat.setStyle("-fx-font-size:18; -fx-padding-left:20;");
                nom.getChildren().add(nomMat);
                Text prixMat = new Text(Double.toString(materiel.getPrix()));
                prixMat.setStyle("-fx-font-size:18; -fx-padding-right:20;");
                prix.getChildren().add(prixMat);
            }

            //Ajout des dépenses de nourriture
            for (Nourriture nourriture : seminaire.getMenu()) {
                //Création hbox principale
                HBox conteneur2 = new HBox();
                conteneur2.setPrefSize(450.0, 50.0);
                conteneur2.setMaxSize(450.0, 50.0);
                conteneur2.setAlignment(Pos.CENTER_LEFT);
                conteneur2.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10; -fx-padding:10");
                vboxDepense.getChildren().add(conteneur2);

                //Elements hbox
                HBox nom = new HBox();
                nom.setPrefSize(200.0, 100.0);
                nom.setAlignment(Pos.CENTER_LEFT);
                HBox prix = new HBox();
                prix.setPrefSize(272.0, 100.0);
                prix.setAlignment(Pos.CENTER_RIGHT);
                conteneur2.getChildren().add(nom);
                conteneur2.getChildren().add(prix);

                //Textes
                Text nomFood = new Text(nourriture.getNom());
                nomFood.setStyle("-fx-font-size:18; -fx-padding-left:20;");
                nom.getChildren().add(nomFood);
                Text prixFood = new Text(Double.toString(nourriture.getPrix()));
                prixFood.setStyle("-fx-font-size:18; -fx-padding-right:20;");
                prix.getChildren().add(prixFood);
            }

            //Ajout des dépenses de nourriture
            //Création hbox
            HBox conteneur2 = new HBox();
            conteneur2.setPrefSize(450.0, 50.0);
            conteneur2.setMaxSize(450.0, 50.0);
            conteneur2.setAlignment(Pos.CENTER_LEFT);
            conteneur2.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10; -fx-padding:10");
            vboxDepense.getChildren().add(conteneur2);

            //Elements hbox
            HBox nom = new HBox();
            nom.setPrefSize(200.0, 100.0);
            nom.setAlignment(Pos.CENTER_LEFT);
            HBox prix = new HBox();
            prix.setPrefSize(272.0, 100.0);
            prix.setAlignment(Pos.CENTER_RIGHT);
            conteneur2.getChildren().add(nom);
            conteneur2.getChildren().add(prix);

            //Textes
            if (!seminaire.getInvites().isEmpty()) {
                Text nomHotel = new Text(seminaire.getHotel().getNom());
                nomHotel.setStyle("-fx-font-size:18; -fx-padding-left:20;");
                nom.getChildren().add(nomHotel);
                Text prixHotel = new Text(Double.toString(seminaire.getHotel().getPrixPersonne() * seminaire.getInvites().size()));
                prixHotel.setStyle("-fx-font-size:18; -fx-padding-right:20;");
                prix.getChildren().add(prixHotel);
            }
            LOGGER.info("Chargement du budget pour le séminaire de nom: " + seminaire.getNom() + " réussi");
        }

    }

    // --------------------- Commun -------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {

            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition des évènements
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void back(ActionEvent event) throws IOException, ExceptionInterface {
        if (seminaire != null) {
            LOGGER.info("changement interface précédente en cours");
            Parent parent;
            ModifyEventControleur modifyEventControleur2 = new ModifyEventControleur(genEvent, null, seminaire);
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
                fxmlLoader.setController(modifyEventControleur2);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur2.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        } else {
            LOGGER.info("changement interface précédente en cours");
            ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
                fxmlLoader.setController(modifyEventControleur);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        }

    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition pour les évènements classés dans les archives
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void backArchives(ActionEvent event) throws IOException, ExceptionInterface {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-event-view.fxml"));
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
        Parent parent;
        try {
            fxmlLoader.setController(modifyEventControleur);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        modifyEventControleur.initializeModify();
    }
}
