package fr.uga.iut2.genevent.modele;


import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class Evenement implements Serializable {
    private String nom;
    private String lieu;
    private LocalDate date;
    private double budget;
    private final TypeEvenement type;
    private int numPlaylist;

    private final ArrayList<Materiel> materiels = new ArrayList<>();

    private final ArrayList<Nourriture> nourritures = new ArrayList<>();

    private final ArrayList<Invite> invites = new ArrayList<>();



    /**
     * Crée un objet de type évènement en initialisant le numéro de playlist à 0
     * @param nom nom de l'évènement
     * @param lieu lieu de l'évènement
     * @param date date de début de l'évènement
     * @param type type d'évènement (séminaire, afterwork, etc.)
     * @param budget le budget de l'évènement
     */
    public Evenement(String nom, String lieu, LocalDate date, TypeEvenement type, Double budget) {
        this.nom = nom;
        this.lieu = lieu;
        this.date = date;
        this.type = type;
        this.budget = budget;
        setNumPlaylist(0);
    }

    /**
     * Permet d'accéder au nom de l'évènement
     * @return le nom
     */
    public String getNom() {
        return this.nom;
    }


    /**
     * Permet d'accéder à la date de début de l'évènement
     * @return la date
     */
    public LocalDate getDate() {
        return this.date;
    }

    /**
     * Permet d'accéder au budget de l'évènement
     * @return le budget
     */
    public double getBudget() {
        return this.budget;
    }

    /**
     * Permet d'accéder au lieu de l'évènement
     * @return le lieu
     */
    public String getLieu() {
        return this.lieu;
    }

    /**
     * Modifie le nom de l'évènement
     * @param nom nouveau nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Modifie le budget de l'évènement
     * @param budget nouveau budget
     */
    public void setBudget(double budget) {
        this.budget = budget;
    }

    /**
     * Modifie la date de début de l'évènement
     * @param date nouvelle date
     */
    public void setDate(LocalDate date) {
        this.date = date;
    }

    /**
     * Modifie le lieu de l'évènement
     * @param lieu nouveau lieu
     */
    public void setLieu(String lieu) {
        this.lieu = lieu;
    }

    /**
     * Permet d'accéder au type de l'évènement
     * @return le type
     */
    public TypeEvenement getType() {
        return this.type;
    }

    /**
     * Ajoute un objet de type matériel pour l'évènement si le budget le permet
     * @param materiel matériel à ajouter
     */
    public void addMateriel(Materiel materiel) {
        if(getBudgetCourrant() - materiel.getPrix()>=0) {
            this.materiels.add(materiel);
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Your remaining money is too low. " +
                    "\nIncrease it to add new material", ButtonType.OK);
            alert.showAndWait();
        }
    }

    /**
     * Enregistrer un nouveau numéro de playlist
     * @param numPlaylist numéro de la nouvelle playlist
     */
    public void setNumPlaylist(int numPlaylist) {
        this.numPlaylist = numPlaylist;
    }

    /**
     * Permet d'obtenir le numéro de la playlist
     * @return le numéro de la playlist
     */
    public int getNumPlaylist() {
        return numPlaylist;
    }

    /**
     * Supprime un objet de type matériel pour l'évènement
     * @param materiel matériel à supprimer
     */
    public void removeMateriel(Materiel materiel) {
        this.materiels.remove(materiel);
    }

    /**
     * Permet d'accéder à la liste de matériel de l'évènement
     * @return la liste de matériel
     */
    public ArrayList<Materiel> getMateriels() {
        return this.materiels;
    }

    /**
     * Ajoute un objet de type nourriture pour l'évènement si le budget le permet
     * @param nourriture nourriture à ajouter
     */
    public void addNourriture(Nourriture nourriture) {
        if(getBudgetCourrant() - nourriture.getPrix() >=0) {
            this.nourritures.add(nourriture);
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Your remaining money is too low. " +
                    "\nIncrease it to add new food", ButtonType.OK);
            alert.showAndWait();
        }
    }

    /**
     * Supprime un objet de type nourriture pour l'évènement
     * @param nourriture nourriture à supprimer
     */
    public void removeNourriture(Nourriture nourriture) {
        this.nourritures.remove(nourriture);
    }

    /**
     * Permet d'accéder au menu de l'évènement
     * @return la liste de nourriture
     */
    public ArrayList<Nourriture> getMenu() {
        return this.nourritures;
    }

    /**
     * Ajoute un invité à l'évènement
     * @param invite invité à ajouter
     */
    public void addInvite(Invite invite) {
        this.invites.add(invite);
    }

    /**
     * Supprime un invité à l'évènement
     * @param invite invité à supprimer
     */
    public void removeInvite(Invite invite) {
        this.invites.remove(invite);
    }

    /**
     * Permet d'accéder à la liste des invités de l'évènement
     * @return la liste d'invités
     */
    public ArrayList<Invite> getInvites() {
        return this.invites;
    }

    /**
     * Permet d'accéder au budget restant d'un évènement (en déduisant le prix du matériel et de la nourriture)
     * @return le budget restant
     */

    public double getBudgetCourrant(){
        double budgetCourrant = this.budget;
        //Pour chaque matériel de l'évènement, enlever le prix au budget
        for (Materiel materiel : materiels){
            budgetCourrant-= materiel.getPrix();
        }
        //Pour chaque nourriture de l'évènement, enlever le prix au budget
        for(Nourriture nourriture : nourritures){
            budgetCourrant-= nourriture.getPrix();
        }
        return budgetCourrant;
    }

    /**
     * Créer une copie de l'évenement
     *
     * @return une copie de l'événement avec (copie) dans son nom
     */
    public Evenement dupliquer() {
        Evenement newEvenement = new Evenement(nom + " (copie)", lieu, date, type, budget);
        newEvenement.setNumPlaylist(numPlaylist);
        for(Nourriture nourriture : nourritures) {
            newEvenement.addNourriture(nourriture);
        }
        for (Invite invite : invites) {
            newEvenement.addInvite(invite);
        }
        for (Materiel materiel : materiels) {
            newEvenement.addMateriel(materiel);
        }
        return newEvenement;
    }
}
