package fr.uga.iut2.genevent.modele;

import java.io.Serializable;

public class Musique implements Serializable {
    private String nom;
    private String artiste;

    /**
     * Constructeur Musique avec comme parametres le nom et l'artiste de la musique
     * @param nom le nom de la musique
     * @param artiste le nom de l'artiste qui chante cette musique
     */
    public Musique(String nom, String artiste) {
        setNom(nom);
        setArtiste(artiste);
    }

    /**
     * Permet d'acceder au nom de la musique
     * @return le nom de la musique
     */
    public String getNom() {
        return nom;
    }

    /**
     * Permet d'acceder à l'artiste de la musique
     * @return l'artiste de la musique
     */
    public String getArtiste() {
        return artiste;
    }

    /**
     * Permet d'attribuer un nom à une musique
     * @param nom le nom de la musique
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Permet d'attribuer un artiste à une musique
     * @param artiste l'artiste de la musique
     */
    public void setArtiste(String artiste) {
        this.artiste = artiste;
    }
}
