package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.ExceptionInterface;
import fr.uga.iut2.genevent.modele.GenEvent;
import fr.uga.iut2.genevent.modele.TypeEvenement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * Gère les interactions des boutons de la page d'Accueil
 * Permet d'accéder aux listes d'évènements, les paramètres et les archives
 */
public class ControleurAccueil {

    //Attributs
    private GenEvent genEvent;
    public static final Logger LOGGER = Logger.getLogger(ControleurAccueil.class.getName());

    //Constructeur
    public ControleurAccueil(GenEvent genEvent) {
        this.genEvent = genEvent;
    }

    //Méthodes
    /**
     * Gère l'interaction avec le bouton 'Party'
     * Permet d'accéder à la liste des évènements de type 'Party'
     *
     * @param event l'événement de clic sur le bouton 'Party'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void typeParty(ActionEvent event) throws IOException, ExceptionInterface {
        //Crée un nouveau controleur liste pour initialiser la liste des évènements
        LOGGER.info("bouton Leaving Party click");
        ControleurListe controleurListe = new ControleurListe(genEvent);
        Parent parent;
        //Label pour attribuer le type à chaque évènement
        Label label = new Label("Leaving party");
        //Tentative de chargement de la page des évènement de type 'Party' (sinon renvoie une exception)
        try {
            controleurListe.setTypeEvenement(TypeEvenement.POT_DE_DEPART);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            fxmlLoader.setController(controleurListe);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        //Affichage de la page
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurListe.setType(label);
        LOGGER.info("changement interface evenement réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Integration Party'
     * Permet d'accéder à la liste des évènements de type 'Integration Party'
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void typeInte(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton Integration Party click");
        ControleurListe controleurListe = new ControleurListe(genEvent);
        Parent parent;
        Label label = new Label("Integration party");
        try {
            controleurListe.setTypeEvenement(TypeEvenement.SOIREE_DINTEGRATION);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            fxmlLoader.setController(controleurListe);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurListe.setType(label);
        LOGGER.info("changement interface evenement réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Conference'
     * Permet d'accéder à la liste des évènements de type 'Conference'
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void typeConf(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton Conference click");
        ControleurListe controleurListe = new ControleurListe(genEvent);
        Parent parent;
        Label label = new Label("Conference");
        try {
            controleurListe.setTypeEvenement(TypeEvenement.CONFERENCE);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            fxmlLoader.setController(controleurListe);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurListe.setType(label);
        LOGGER.info("changement interface evenement réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Seminar'
     * Permet d'accéder à la liste des évènements de type 'Seminar'
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void typeSeminaire(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton Seminar click");
        ControleurListe controleurListe = new ControleurListe(genEvent);
        Parent parent;
        Label label = new Label("Seminar");
        try {
            controleurListe.setTypeEvenement(TypeEvenement.SEMINAIRE);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            fxmlLoader.setController(controleurListe);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurListe.setType(label);
        LOGGER.info("changement interface evenement réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Team Building'
     * Permet d'accéder à la liste des évènements de type 'Team Building'
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void typeTeamBuilding(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton Team Building click");
        ControleurListe controleurListe = new ControleurListe(genEvent);
        Parent parent;
        Label label = new Label("Team Building");
        try {
            controleurListe.setTypeEvenement(TypeEvenement.TEAMBUILDING);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            fxmlLoader.setController(controleurListe);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurListe.setType(label);
        LOGGER.info("changement interface evenement réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Afterwork Party'
     * Permet d'accéder à la liste des évènements de type 'Afterwork Party'
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void typeAfterwork(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton Afterwork Party click");
        ControleurListe controleurListe = new ControleurListe(genEvent);
        Parent parent;
        Label label = new Label("Afterwork party");
        try {
            controleurListe.setTypeEvenement(TypeEvenement.SOIREE_AFTERWORK);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/list-event-view.fxml"));
            fxmlLoader.setController(controleurListe);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurListe.setType(label);
        LOGGER.info("changement interface evenement réussi");
    }

    // --------------------------- Commun ------------------------
    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface setting réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }
}
