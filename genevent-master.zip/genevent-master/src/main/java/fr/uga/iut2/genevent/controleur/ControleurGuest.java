package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

public class ControleurGuest {

    //Attributs
    private GenEvent genEvent;
    private Evenement evenement;
    private Seminaire seminaire;
    public static final Logger LOGGER = Logger.getLogger(ControleurGuest.class.getName());
    @FXML private TextField nomInvite, emailInvite;
    @FXML private VBox vBoxAjout;
    @FXML private Text guestTitre;

    //Constructeurs
    public ControleurGuest(GenEvent genEvent, Evenement event) {
        this.genEvent = genEvent;
        this.evenement = event;
    }

    public ControleurGuest(GenEvent genEvent, Seminaire seminaire) {
        this.genEvent = genEvent;
        this.seminaire = seminaire;
    }

    //Méthodes

    /**
     * Initialise la liste des invités d'un évènement et l'affiche
     * Ajoute les conteneurs et le style nécessaire
     */
    public void initializeInvite() {
        LOGGER.info("chargement des invités en cours");
        ArrayList<Invite> invites = new ArrayList<>();
        if (evenement != null) {
            invites = evenement.getInvites();
        } else if (seminaire != null) {
            invites = seminaire.getInvites();
        }
        for (Invite invite : invites) {
            //Création et options des conteneurs
            HBox hboxInv = new HBox();
            VBox vNomInv = new VBox();
            HBox deleteInv = new HBox();
            hboxInv.setPrefSize(700.0, 100.0);
            hboxInv.setMaxSize(700.0, 100.0);

            // Création et options des contrôleurs
            Text nomInv = new Text(invite.getNom());
            Text email = new Text(invite.getMail());
            email.setStyle("-fx-font-size:18;");
            nomInv.setStyle("-fx-font-size:18;");

            Button boutonDeleteInv = new Button();
            boutonDeleteInv.setUserData(invite);
            boutonDeleteInv.setOnAction(e -> {
                try {
                    deleteGuestPopUp(e);
                } catch (IOException | ExceptionInterface ex) {
                    throw new RuntimeException(ex);
                }
            });

            // Ajout des objets dans les conteneurs
            vBoxAjout.getChildren().add(hboxInv);
            hboxInv.getChildren().addAll(vNomInv, deleteInv);
            deleteInv.getChildren().add(boutonDeleteInv);
            vNomInv.getChildren().addAll(nomInv, email);


            // Ajout de l'image du bouton delete
            Image bin = new Image(String.valueOf(getClass().getResource("/fr/uga/iut2/genevent/vue/icon/bin.png")));
            ImageView binView = new ImageView(bin);
            binView.setFitWidth(40);
            binView.setFitHeight(40);
            boutonDeleteInv.setStyle("-fx-background-color:transparent");
            boutonDeleteInv.setGraphic(binView);

            //Options des conteneurs
            deleteInv.setAlignment(Pos.CENTER_RIGHT);
            vNomInv.setAlignment(Pos.CENTER_LEFT);
            vNomInv.setPrefSize(640, 100);
            deleteInv.setPrefWidth(50);
            hboxInv.setPrefSize(700, 100);
            hboxInv.setMaxSize(700, 100);
            vNomInv.setPadding(new Insets(0, 0, 0, 20));
            deleteInv.setPadding(new Insets(0, 20, 0, 0));

            hboxInv.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10;");
            LOGGER.info("chargement des invités réussis");
        }
    }

    /**
     * Affiche un pop up pour créer un invité
     *
     * @param event clic sur le bouton '+'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void createGuestPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        Stage stage = new Stage();
        Scene scenePrincipal = guestTitre.getScene();
        Stage stagePrincipal = (Stage) scenePrincipal.getWindow();
        //Pour un évènement
        if (evenement != null) {
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/new-guest-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = new Scene(parent, 400, 400);
            stage.setScene(scene);
            stage.show();
        }
        //Pour un séminaire
        else if (seminaire != null) {
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, seminaire);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/new-guest-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                parent = fxmlLoader.load();
            }catch (IOException e){
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = new Scene(parent, 400, 400);
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Affiche un pop up pour confirmer la supression d'un invité
     *
     * @param event clic sur le bouton en forme de poubelle
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void deleteGuestPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        Stage stage = new Stage();
        Scene scenePrincipal = guestTitre.getScene();
        Stage stagePrincipal = (Stage) scenePrincipal.getWindow();
        Node node = (Node) event.getSource();
        stagePrincipal.setUserData(node.getUserData());
        //Pour un évènement
        if (evenement != null) {
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/delete-guest-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                parent = fxmlLoader.load();
                Scene scene = new Scene(parent, 400, 200);
                stage.setScene(scene);
                stage.show();
            }catch (IOException e){
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
        }
        //Pour un séminaire
        else if (seminaire != null) {
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, seminaire);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/delete-guest-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                parent = fxmlLoader.load();
                Scene scene = new Scene(parent, 400, 200);
                stage.setScene(scene);
                stage.show();
            }catch (IOException e){
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
        }
    }

    /**
     * Initialise la liste des invités d'un évènement classé dans les archives et l'affiche
     * Ajoute les conteneurs et le style nécessaire
     */
    public void initializeInviteArchives() {
        LOGGER.info("Chargement des archives des invités en cours");
        for (Invite invite : evenement.getInvites()) {
            //Création et options des conteneurs
            HBox hboxInv = new HBox();
            VBox vNomInv = new VBox();
            hboxInv.setPrefSize(700.0, 100.0);
            hboxInv.setMaxSize(700.0, 100.0);

            // Création et options des contrôleurs
            Text nomInv = new Text(invite.getNom());
            hboxInv.getChildren().add(nomInv);
            Text email = new Text(invite.getMail());
            email.setStyle("-fx-font-size:18;");
            nomInv.setStyle("-fx-font-size:18;");

            // Ajout des objets dans les conteneurs
            vBoxAjout.getChildren().add(hboxInv);
            hboxInv.getChildren().add(vNomInv);
            vNomInv.getChildren().addAll(nomInv, email);

            //options des conteneurs
            vNomInv.setAlignment(Pos.CENTER_LEFT);
            vNomInv.setPrefSize(700, 100);
            hboxInv.setPrefSize(700, 100);
            hboxInv.setMaxSize(700, 100);
            vNomInv.setPadding(new Insets(0, 0, 0, 20));

            hboxInv.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10;");

        }
        LOGGER.info("Chargement des archives des invités réussi");
    }


    // --------------------- Commun -------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface setting réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives.fxml"));
            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition des évènements
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void back(ActionEvent event) throws IOException, ExceptionInterface {
        if (seminaire != null) {
            LOGGER.info("changement interface précédente en cours");
            Parent parent;
            ModifyEventControleur modifyEventControleur2 = new ModifyEventControleur(genEvent, null, seminaire);
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
                fxmlLoader.setController(modifyEventControleur2);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur2.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        } else {
            LOGGER.info("changement interface précédente en cours");
            ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
                fxmlLoader.setController(modifyEventControleur);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        }
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition pour les évènements classés dans les archives
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void backArchives(ActionEvent event) throws IOException, ExceptionInterface {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-event-view.fxml"));
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
        Parent parent;
        try {
            fxmlLoader.setController(modifyEventControleur);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        modifyEventControleur.initializeModify();
    }
}
