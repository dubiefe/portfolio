package fr.uga.iut2.genevent.modele;

import fr.uga.iut2.genevent.controleur.ControleurAccueil;

import java.util.logging.Logger;

public class ExceptionInterface extends Exception{

    public static final Logger LOGGER = Logger.getLogger(ExceptionInterface.class.getName());
    public ExceptionInterface(String s) {
        LOGGER.severe(s);
    }
}
