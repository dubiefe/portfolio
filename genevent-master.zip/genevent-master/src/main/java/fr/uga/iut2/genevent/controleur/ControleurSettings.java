package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.ExceptionInterface;
import fr.uga.iut2.genevent.modele.GenEvent;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.logging.Logger;

public class ControleurSettings {
    //Attributs
    private GenEvent genEvent;
    public static final Logger LOGGER = Logger.getLogger(ControleurSettings.class.getName());
    @FXML private SplitPane settings, archives, budget, consulterEvent, modifierEvent, menu, guest, main, material, playlist;
    @FXML private AnchorPane createEvent, invitation;
    @FXML private VBox delete, newGuest, newMaterial;

    //Constructeur
    public ControleurSettings(GenEvent genEvent) {
        this.genEvent = genEvent;
    }

    //Méthodes
    /**
     * Applique le thème sombre
     *
     * @param event l'événement clic sur le bouton 'Dark'
     */
    @FXML
    public void onBtnDark(Event event) {
        LOGGER.info("Bouton dark mode click");
        settings.getStylesheets().clear();
        settings.getStylesheets().add(String.valueOf(this.getClass().getResource("/fr/uga/iut2/genevent/vue/styleDark.css")));
    }

    /**
     * Applique le thème clair
     *
     * @param event l'événement clic sur le bouton 'Light'
     */
    @FXML
    public void onBtnLight(Event event) {
        LOGGER.info("Bouton light mode click");
        settings.getStylesheets().clear();
        settings.getStylesheets().add(String.valueOf(this.getClass().getResource("/fr/uga/iut2/genevent/vue/styleLight.css")));
    }

    // --------------------------- Commun ----------------------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-view.fxml"));
            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }
}
