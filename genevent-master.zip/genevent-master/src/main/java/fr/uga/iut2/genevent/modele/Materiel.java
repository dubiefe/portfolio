package fr.uga.iut2.genevent.modele;

import java.io.Serializable;

public class Materiel implements Serializable {

    //Attributs

    private String nom;
    private double prix;
    private int quantite;

    //Constructeur

    /**
     * Construit un objet de type matériel avec un nom, un prix et une quantité
     * @param nom nom du matériel
     * @param prix prix du matériel
     * @param quantite quantité du produit à ajouter
     */
    public Materiel(String nom, double prix, int quantite){
        this.nom = nom;
        this.prix = prix;
        this.quantite = quantite;
    }

    //Getters

    /**
     * Permet d'accéder au nom u matériel
     * @return le nom
     */
    public String getNom(){
        return nom;
    }

    /**
     * Permet d'accéder au prix du matériel selon la quantite
     * @return le prix
     */
    public double getPrix(){
        return prix*quantite;
    }

    /**
     * Permet d'accéder à la quantité de produit demander
     * @return la quantité
     */
    public int getQuantite(){
        return quantite;
    }

    //Setters

    /**
     * Modifie le nom du matériel
     * @param nom nouveau nom
     */
    public void setNom(String nom){
        this.nom = nom;
    }

    /**
     * Modifie le prix du matériel
     * @param prix nouveau prix
     */
    public void setPrix(double prix){
        this.prix = prix;
    }

    /**
     * Modifie la quantité d'un produit
     * @param quantite
     */
    public void setQuantite(int quantite){
        this.quantite = quantite;
    }

}
