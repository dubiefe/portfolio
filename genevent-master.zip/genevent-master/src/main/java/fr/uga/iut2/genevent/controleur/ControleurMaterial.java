package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.logging.Logger;

public class ControleurMaterial {

    //Attributs
    private GenEvent genEvent;
    private Evenement evenement;
    private Seminaire seminaire;
    public static final Logger LOGGER = Logger.getLogger(ControleurMaterial.class.getName());
    @FXML TextField nomMatos, quantMatos, prixMatos;
    @FXML private Text materialTitre;
    @FXML private VBox vBoxMat = new VBox();

    //Constructeurs
    public ControleurMaterial(GenEvent genEvent, Evenement event) {
        this.genEvent = genEvent;
        this.evenement = event;
    }

    public ControleurMaterial(GenEvent genEvent, Seminaire seminaire) {
        this.genEvent = genEvent;
        this.seminaire = seminaire;
    }

    //Méthodes

    /**
     * Initialise la liste de matériel
     * Ajoute les conteneurs et le style nécessaire
     */
    public void initializeMaterial() {
        // Itération sur chaque matériel présent dans l"événement
        LOGGER.info("Chargement des matériels en cours");
        ArrayList<Materiel> materials = new ArrayList<>();
        if (evenement != null) {
            materials = evenement.getMateriels();
        } else if (seminaire != null) {
            materials = seminaire.getMateriels();
        }
        for (Materiel matos : materials) {

            // Création des conteneurs
            HBox hBoxMateriel = new HBox();
            HBox hBoxNom = new HBox();
            HBox hBoxDelete = new HBox();
            HBox hBoxQuantite = new HBox();
            HBox hBoxPrix = new HBox();

            // Création du bouton delete et affectation de la méthode associée
            Button boutonDeleteMat = new Button();
            boutonDeleteMat.setUserData(matos);
            boutonDeleteMat.setOnAction(e -> {
                try {
                    deleteMaterialPopUp(e);
                } catch (IOException | ExceptionInterface ex) {
                    throw new RuntimeException(ex);
                }
            });

            // Ajout de l'image du bouton delete
            Image bin = new Image(String.valueOf(getClass().getResource("/fr/uga/iut2/genevent/vue/icon/bin.png")));
            ImageView binView = new ImageView(bin);
            binView.setFitWidth(40);
            binView.setFitHeight(40);
            boutonDeleteMat.setStyle("-fx-background-color:transparent");
            boutonDeleteMat.setGraphic(binView);

            // Options des conteneurs
            hBoxDelete.setAlignment(Pos.CENTER_RIGHT);
            hBoxNom.setAlignment(Pos.CENTER_LEFT);
            hBoxQuantite.setAlignment(Pos.CENTER_LEFT);
            hBoxPrix.setAlignment(Pos.CENTER_LEFT);
            hBoxNom.setPrefWidth(250);
            hBoxQuantite.setPrefWidth(200);
            hBoxPrix.setPrefWidth(200);
            hBoxDelete.setPrefWidth(50);
            hBoxMateriel.setPrefSize(700, 100);
            hBoxMateriel.setMaxSize(700, 100);
            hBoxNom.setPadding(new Insets(0, 0, 0, 20));
            hBoxDelete.setPadding(new Insets(0, 20, 0, 0));
            hBoxMateriel.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10;");

            // Création et options des labels
            Text nomMat = new Text(matos.getNom());
            Label quantite = new Label("Quantité : " + matos.getQuantite());
            Label prix = new Label("Prix : " + matos.getPrix() + "€");
            quantite.setStyle("-fx-font-size:18;");
            prix.setStyle("-fx-font-size:18;");
            nomMat.setStyle("-fx-font-size:18;");

            // Ajout des objets dans les conteneurs
            hBoxDelete.getChildren().add(boutonDeleteMat);
            hBoxMateriel.getChildren().addAll(hBoxNom, hBoxQuantite, hBoxPrix, hBoxDelete);
            hBoxNom.getChildren().add(nomMat);
            hBoxQuantite.getChildren().add(quantite);
            hBoxPrix.getChildren().add(prix);
            vBoxMat.getChildren().add(hBoxMateriel);
        }
        LOGGER.info("Chargement des matériels réussi");
    }

    /**
     * Affiche un pop up pour créer un nouveau matériel
     *
     * @param event l'événement clic sur le bouton d'édition du matériel
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void createMaterialPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        Stage stage = new Stage();
        Scene scenePrincipal = materialTitre.getScene();
        Stage stagePrincipal = (Stage) scenePrincipal.getWindow();
        if (evenement != null) {
            try {
                ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, evenement);
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/new-material-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                Parent parent = fxmlLoader.load();
                Scene scene = new Scene(parent, 400, 400);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }

        } else if (seminaire != null) {
            try {
                ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, seminaire);
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/new-material-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                Parent parent = fxmlLoader.load();
                Scene scene = new Scene(parent, 400, 400);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
        }
    }

    /**
     * Affiche un pop up pour supprimer un matériel
     *
     * @param event l'événement clic sur le bouton en forme de poubelle
     * @throws IOException si le fichier FXML ne peut pas charger
     */
    @FXML
    private void deleteMaterialPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        Stage stage = new Stage();
        Scene scenePrincipal = materialTitre.getScene();
        Stage stagePrincipal = (Stage) scenePrincipal.getWindow();
        Node node = (Node) event.getSource();
        stagePrincipal.setUserData(node.getUserData()); // Définit les données utilisateur pour la fenêtre principale
        if (evenement != null) {
            try {
                ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, evenement);
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/delete-material-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                Parent parent = fxmlLoader.load();
                Scene scene = new Scene(parent, 400, 200);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
        } else if (seminaire != null) {
            try {
                ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, seminaire);
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/delete-material-view.fxml"));
                fxmlLoader.setController(controleurNewAndDelete);
                Parent parent = fxmlLoader.load();
                Scene scene = new Scene(parent, 400, 200);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
        }
    }

     /**
     * Initialise la liste de matériel
     * Ajoute les conteneurs et le style nécessaire
     */

    public void initializeMaterielArchives() {
        LOGGER.info("Chargement des archives de matériels en cours");
        // Itération sur chaque matériel présent dans l"événement
        for (Materiel matos : evenement.getMateriels()) {

            // Création des conteneurs
            HBox hBoxMateriel = new HBox();
            HBox hBoxNom = new HBox();
            HBox hBoxDelete = new HBox();
            HBox hBoxQuantite = new HBox();
            HBox hBoxPrix = new HBox();

            // Options des conteneurs
            hBoxDelete.setAlignment(Pos.CENTER_RIGHT);
            hBoxNom.setAlignment(Pos.CENTER_LEFT);
            hBoxQuantite.setAlignment(Pos.CENTER_LEFT);
            hBoxPrix.setAlignment(Pos.CENTER_LEFT);
            hBoxNom.setPrefWidth(250);
            hBoxQuantite.setPrefWidth(200);
            hBoxPrix.setPrefWidth(200);
            hBoxDelete.setPrefWidth(50);
            hBoxMateriel.setPrefSize(700, 100);
            hBoxMateriel.setMaxSize(700, 100);
            hBoxNom.setPadding(new Insets(0, 0, 0, 20));
            hBoxDelete.setPadding(new Insets(0, 20, 0, 0));
            hBoxMateriel.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10;");

            // Création et options des labels
            Text nomMat = new Text(matos.getNom());
            Label quantite = new Label("Quantité : " + matos.getQuantite());
            Label prix = new Label("Prix : " + matos.getPrix() + "€");
            quantite.setStyle("-fx-font-size:18;");
            prix.setStyle("-fx-font-size:18;");
            nomMat.setStyle("-fx-font-size:18;");

            // Ajout des objets dans les conteneurs
            hBoxMateriel.getChildren().addAll(hBoxNom, hBoxQuantite, hBoxPrix, hBoxDelete);
            hBoxNom.getChildren().add(nomMat);
            hBoxQuantite.getChildren().add(quantite);
            hBoxPrix.getChildren().add(prix);
            vBoxMat.getChildren().add(hBoxMateriel);
        }
        LOGGER.info("Chargement des archives de matériels réussi");
    }

    // --------------------- Commun -------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface setting réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives.fxml"));
            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition des évènements
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void back(ActionEvent event) throws IOException, ExceptionInterface {
        if (seminaire != null) {
            LOGGER.info("changement interface précédente en cours");
            Parent parent;
            ModifyEventControleur modifyEventControleur2 = new ModifyEventControleur(genEvent, null, seminaire);
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
                fxmlLoader.setController(modifyEventControleur2);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur2.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        } else {
            LOGGER.info("changement interface précédente en cours");
            ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
            Parent parent;
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/event-view.fxml"));
                fxmlLoader.setController(modifyEventControleur);
                parent = fxmlLoader.load();
            } catch (IOException e) {
                throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
            }
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur.initializeModify();
            LOGGER.info("changement interface précédente réussie");
        }
    }


    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition pour les évènements classés dans les archives
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void backArchives(ActionEvent event) throws IOException, ExceptionInterface {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-event-view.fxml"));
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
        Parent parent;
        try {
            fxmlLoader.setController(modifyEventControleur);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        modifyEventControleur.initializeModify();
    }
}
