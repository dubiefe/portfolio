package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.ExceptionInterface;
import fr.uga.iut2.genevent.modele.GenEvent;
import fr.uga.iut2.genevent.modele.Seminaire;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.logging.Logger;

public class ControleurHotel {

    //Attributs
    private GenEvent genEvent;
    private Seminaire seminaire;
    public static final Logger LOGGER = Logger.getLogger(ControleurFood.class.getName());
    @FXML private Text hotelTitre;
    @FXML private VBox vBoxHotel;

    //Constructeur
    public ControleurHotel(GenEvent genEvent, Seminaire seminaire) {
        this.genEvent = genEvent;
        this.seminaire = seminaire;
    }

    //Méthodes

    /**
     * Initialise l'hotel d'un séminaire si celui-ci existe
     * Ajoute les conteneurs et le style nécessaire
     */
    public void initializeHotel() {
        // Itération sur chaque matériel présent dans l"événement
        LOGGER.info("Chargement de l'hotel en cours");
        if (seminaire.getHotel() != null) {
            // Création des conteneurs
            HBox hBoxHotel = new HBox();
            HBox hBoxNom = new HBox();
            HBox hBoxDelete = new HBox();
            HBox hBoxPrix = new HBox();

            // Création du bouton delete et affectation de la méthode associée
            Button boutonDeleteHot = new Button();
            boutonDeleteHot.setUserData(seminaire.getHotel());
            boutonDeleteHot.setOnAction(e -> {
                try {
                    deleteHotelPopUp(e);
                } catch (IOException | ExceptionInterface ex) {
                    throw new RuntimeException(ex);
                }
            });

            // Ajout de l'image du bouton delete
            Image bin = new Image(String.valueOf(getClass().getResource("/fr/uga/iut2/genevent/vue/icon/bin.png")));
            ImageView binView = new ImageView(bin);
            binView.setFitWidth(40);
            binView.setFitHeight(40);
            boutonDeleteHot.setStyle("-fx-background-color:transparent");
            boutonDeleteHot.setGraphic(binView);

            // Options des conteneurs
            hBoxDelete.setAlignment(Pos.CENTER_RIGHT);
            hBoxNom.setAlignment(Pos.CENTER_LEFT);
            hBoxPrix.setAlignment(Pos.CENTER_LEFT);
            hBoxNom.setPrefWidth(450);
            hBoxPrix.setPrefWidth(200);
            hBoxDelete.setPrefWidth(50);
            hBoxHotel.setPrefSize(700, 100);
            hBoxHotel.setMaxSize(700, 100);
            hBoxNom.setPadding(new Insets(0, 0, 0, 20));
            hBoxDelete.setPadding(new Insets(0, 20, 0, 0));
            hBoxHotel.setStyle("-fx-border-style:solid; -fx-border-width:2; -fx-border-color:#3498db; -fx-border-radius:10;");

            // Création et options des labels
            Text nomHot = new Text(seminaire.getHotel().getNom());
            Label prix = new Label("Prix : " + seminaire.getHotel().getPrixPersonne() + "€");
            prix.setStyle("-fx-font-size:18;");
            nomHot.setStyle("-fx-font-size:18;");

            // Ajout des objets dans les conteneurs
            hBoxDelete.getChildren().add(boutonDeleteHot);
            hBoxHotel.getChildren().addAll(hBoxNom, hBoxPrix, hBoxDelete);
            hBoxNom.getChildren().add(nomHot);
            hBoxPrix.getChildren().add(prix);
            vBoxHotel.getChildren().add(hBoxHotel);
        }
        LOGGER.info("Chargement de l'hotel réussi");
    }

    /**
     * Affiche un pop up pour créer un hotel pour un séminaire
     *
     * @param event l'évènement de clic sur le bouton '+'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    private void createHotelPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Affichage popup création d'un hotel");
        try {
            Stage stage = new Stage();
            Scene scenePrincipal = hotelTitre.getScene();
            Stage stagePrincipal = (Stage) scenePrincipal.getWindow();
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, seminaire);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/new-hotel-view.fxml"));
            fxmlLoader.setController(controleurNewAndDelete);
            Parent parent = fxmlLoader.load();
            Scene scene = new Scene(parent, 400, 400);
            stage.setScene(scene);
            stage.show();
        }catch (IOException e){
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
    }

    /**
     * Affiche un pop up pour supprimer l'hotel d'un séminaire
     *
     * @param event l'évènement de clic sur le bouton en forme de poubelle
     * @throws IOException si le fichier FXML ne peut pas être chargé
     * @throws ExceptionInterface si l'interface ne répond pas
     */
    @FXML
    private void deleteHotelPopUp(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("Affichage popup suppresion d'un hotel");
        try {
            Stage stage = new Stage();
            Scene scenePrincipal = hotelTitre.getScene();
            Stage stagePrincipal = (Stage) scenePrincipal.getWindow();
            Node node = (Node) event.getSource();
            stagePrincipal.setUserData(node.getUserData()); // Définit les données utilisateur pour la fenêtre principale
            ControleurNewAndDelete controleurNewAndDelete = new ControleurNewAndDelete(genEvent, stagePrincipal, seminaire);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/newAndDelete/delete-hotel-view.fxml"));
            fxmlLoader.setController(controleurNewAndDelete);
            Parent parent = fxmlLoader.load();
            Scene scene = new Scene(parent, 400, 200);
            stage.setScene(scene);
            stage.show();
        }catch (IOException e){
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }

    }

    // --------------------- Commun -------------------
    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface setting réussi");
    }

    /**
     * Gère l'interaction avec le bouton 'Archives'
     * Affiche la liste des évènements passés et non modifiables
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void archive(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton archive click");
        Parent parent;
        ControleurArchive controleurArchive = new ControleurArchive(genEvent);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives.fxml"));
            fxmlLoader.setController(controleurArchive);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        controleurArchive.initializeArchives();
        LOGGER.info("changement interface archive réussi");
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition des évènements
     *
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void back(ActionEvent event) throws IOException, ExceptionInterface {
        try {
            ModifyEventControleur modifyEventControleur2 = new ModifyEventControleur(genEvent, null, seminaire);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/Seminar/seminar-view.fxml"));
            fxmlLoader.setController(modifyEventControleur2);
            Parent parent = fxmlLoader.load();
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(parent);
            scene.getWindow().sizeToScene();
            modifyEventControleur2.initializeModify();
        }catch (IOException e){
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
    }

    /**
     * Permet de retourner à la page précédente  pour les boutons d'édition pour les évènements classés dans les archives
     * @param event l'événement clic sur le bouton 'back'
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    private void backArchives(ActionEvent event) throws IOException, ExceptionInterface {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-event-view.fxml"));
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, seminaire);
        Parent parent;
        try {
            fxmlLoader.setController(modifyEventControleur);
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        modifyEventControleur.initializeModify();
    }
}
