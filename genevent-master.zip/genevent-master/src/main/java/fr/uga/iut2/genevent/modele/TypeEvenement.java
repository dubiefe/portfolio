package fr.uga.iut2.genevent.modele;

public enum TypeEvenement{
    SEMINAIRE,
    SOIREE_AFTERWORK,
    POT_DE_DEPART,
    SOIREE_DINTEGRATION,
    TEAMBUILDING,
    CONFERENCE
}
