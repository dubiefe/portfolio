package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.GenEvent;
import fr.uga.iut2.genevent.vue.IHM;
import fr.uga.iut2.genevent.vue.JavaFXGUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;


public class Controleur {

    private final GenEvent genevent;
    private final IHM ihm;

    //Constructeur
    public Controleur(GenEvent genevent) {
        this.genevent = genevent;

        // choisir la classe CLI ou JavaFXGUI
        //this.ihm = new CLI(this);
        this.ihm = new JavaFXGUI(this);
    }

    /**
     * Démarre l'interaction avec l'interface utilisateur
     */
    public void demarrer() {
        this.ihm.demarrerInteraction();
    }

    /**
     * Permet de saisir les informations de l'utilisateur
     */
    public void saisirUtilisateur() {
        this.ihm.saisirUtilisateur();
    }

    /**
     * Permet d'accéder au générateur d'évènements
     *
     * @return le générateur d'événements
     */
    public GenEvent getGenevent() {
        return genevent;
    }
}
