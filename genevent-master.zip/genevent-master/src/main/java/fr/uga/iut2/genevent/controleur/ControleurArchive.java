package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.Evenement;
import fr.uga.iut2.genevent.modele.ExceptionInterface;
import fr.uga.iut2.genevent.modele.GenEvent;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.logging.Logger;

/**
 * Le ControleurArchive gère les interactions sur la page des archives de l'application.
 * Il permet de naviguer vers la page d'accueil, les paramètres, et d'afficher les événements archivés.
 */
public class ControleurArchive {

    //Attributs
    public static final Logger LOGGER = Logger.getLogger(ControleurArchive.class.getName());
    private GenEvent genEvent;
    @FXML private VBox listeEvent;

    //Constructeur
    public ControleurArchive(GenEvent genEvent) {
        this.genEvent = genEvent;
    }

    //Méthodes

    /**
     * Initialise la liste des évènements passés et l'affiche
     * Ajoute les conteneurs et le style nécessaire
     */
    public void initializeArchives() {
        LOGGER.info("Chargement des évènements archivés ");
        //Pour chaque évènement
        for (Evenement evenement : genEvent.getEvenements()) {
            //Si la date est dépassée, afficher l'évènement sur la page
            if (evenement.getDate().isBefore(LocalDate.now())) {
                HBox eventBox = new HBox();
                Button button = new Button();
                Label label = new Label();
                listeEvent.getChildren().add(eventBox);
                button.setText(evenement.getNom());
                label.setText("on " + evenement.getDate() + " at " + evenement.getLieu());
                button.setGraphic(label);
                button.setContentDisplay(ContentDisplay.BOTTOM);
                eventBox.getChildren().add(button);
                button.setStyle("-fx-background-color:#d5e7f7; -fx-border-color:#3498db; -fx-border-radius:10; -fx-border-width:2; -fx-pref-width:750; -fx-pref-height:100; -fx-alignment:center-left;");
                button.setUserData(evenement);
                button.setOnAction(e -> {
                    try {
                        seeEventArchives(e);
                    } catch (IOException | ExceptionInterface ex) {
                        throw new RuntimeException("échec changement d'interface");
                    }
                });
            }
        }
        LOGGER.info("Chargement des évènements archivés réussi");
    }

    /**
     * Redirige vers la page permettant de consulter les détails de l'évènement (non modifiables)
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    private void seeEventArchives(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("chargement de la page en cours");
        Node node = (Node) event.getSource();
        Evenement evenement = (Evenement) node.getUserData();
        Stage stage = (Stage) node.getScene().getWindow();
        ModifyEventControleur modifyEventControleur = new ModifyEventControleur(genEvent, null, evenement);
        Parent parent;
        try{
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/archive/archives-event-view.fxml"));
            fxmlLoader.setController(modifyEventControleur);
            parent = fxmlLoader.load();
        }catch (IOException e){
            throw new ExceptionInterface("Echec de chargement de l'interface raison: "+e.getMessage());
        }
        Scene scene = new Scene(parent, 1000, 600);
        stage.setScene(scene);
        stage.show();
        modifyEventControleur.initializeModify();
        LOGGER.info("Chargement de la page réussi");
    }

    // ------------------------ Commun -----------------------------

    /**
     * Gère l'interaction avec le bouton 'Home'
     * Redirige vers la page d'accueil
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void home(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton home click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/main-view.fxml"));
            fxmlLoader.setController(new ControleurAccueil(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface home réussi");
    }

    /**
     * Gère l'interaction avec le bouton settings
     * Redirige vers la page des paramètres
     *
     * @param event l'événement de clic sur le bouton
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @FXML
    public void setting(ActionEvent event) throws IOException, ExceptionInterface {
        LOGGER.info("bouton setting click");
        Parent parent;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fr/uga/iut2/genevent/vue/settings-view.fxml"));
            fxmlLoader.setController(new ControleurSettings(genEvent));
            parent = fxmlLoader.load();
        } catch (IOException e) {
            throw new ExceptionInterface("Echec de chargement de l'interface raison: " + e.getMessage());
        }
        Scene scene = ((Node) event.getSource()).getScene();
        scene.setRoot(parent);
        scene.getWindow().sizeToScene();
        LOGGER.info("changement interface settings réussi");
    }
}
