package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MusiqueTest {

    @Test
    void getNom() {
        Musique mus=new Musique("nom","artiste");
        assertEquals(mus.getNom(),"nom");
    }

    @Test
    void getArtiste() {
        Musique mus=new Musique("nom","artiste");
        assertEquals(mus.getArtiste(),"artiste");
    }

    @Test
    void setNom() {
        Musique mus=new Musique("nom","artiste");
        mus.setNom("musique");
        assertEquals(mus.getNom(),"musique");
    }

    @Test
    void setArtiste() {
        Musique mus=new Musique("nom","artiste");
        mus.setArtiste("ARTISTE");
        assertEquals(mus.getArtiste(),"ARTISTE");
    }
}