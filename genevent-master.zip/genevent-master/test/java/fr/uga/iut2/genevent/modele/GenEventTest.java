package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class GenEventTest {


    @Test
    void addEvent() {
        GenEvent genEvent = new GenEvent();
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        genEvent.addEvent(event);
        ArrayList<Evenement> events = genEvent.getEvenements();
        assertEquals(events.size(),1);
    }

    @Test
    void eventExist() {
        GenEvent genEvent = new GenEvent();
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        genEvent.addEvent(event);
        assertTrue(genEvent.eventExist("event"));
    }


    @Test
    void trieEvent() {
        GenEvent genEvent = new GenEvent();
        Evenement event1 = new Evenement("event", "loc", LocalDate.now(), TypeEvenement.CONFERENCE, 100.0);
        Evenement event2 = new Evenement("evenement", "location", LocalDate.now().plusDays(1), TypeEvenement.SEMINAIRE, 200.0);
        genEvent.addEvent(event1);
        genEvent.addEvent(event2);
        ArrayList<Evenement> trier = genEvent.trieEvent(genEvent.getEvenements(), TypeEvenement.CONFERENCE);
        assertEquals(event1, trier.get(0));
        assertEquals(1, trier.size());


    }


    @Test
    void getEvenements() {
        GenEvent genEvent = new GenEvent();
        Evenement event = new Evenement("event", "location", LocalDate.now(), TypeEvenement.CONFERENCE, 100.0);
        genEvent.addEvent(event);
        ArrayList<Evenement> eve = genEvent.getEvenements();
        assertEquals(1,eve.size());
    }

    @Test
    void getListe() {
        GenEvent genEvent = new GenEvent();
        Evenement event = new Evenement("event", "location", LocalDate.now(), TypeEvenement.CONFERENCE, 100.0);
        Evenement event2 = new Evenement("event", "location", LocalDate.now(), TypeEvenement.TEAMBUILDING, 100.0);
        genEvent.addEvent(event);
        genEvent.addEvent(event2);
        ArrayList<Evenement> conferences = genEvent.getListe(TypeEvenement.CONFERENCE);
        assertEquals(1,conferences.size());
        assertEquals(event,conferences.get(0));

    }
}