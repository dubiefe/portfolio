package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HotelTest {

    @Test
    void getNom() {
        Hotel h=new Hotel("hotel",12.0);
        assertEquals(h.getNom(),"hotel");
    }

    @Test
    void setNom() {
        Hotel h=new Hotel("hotel",12.0);
        h.setNom("nom");
        assertEquals(h.getNom(),"nom");
    }

    @Test
    void getPrixPersonne() {
        Hotel h=new Hotel("hotel",12.0);
        assertEquals(h.getPrixPersonne(),12.0);
    }

    @Test
    void setPrixPersonne() {
        Hotel h=new Hotel("hotel",12.0);
        h.setPrixPersonne(10.0);
        assertEquals(h.getPrixPersonne(),10.0);
    }
}