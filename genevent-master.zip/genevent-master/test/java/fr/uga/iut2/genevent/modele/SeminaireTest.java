package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class SeminaireTest {

    @Test
    void getHotel() {
        Seminaire sem=new Seminaire("nom","lieu", LocalDate.now(),TypeEvenement.CONFERENCE,12.0,LocalDate.MAX);
        Hotel H=new Hotel("hotel",10.0);
        sem.setHotel(H);
        assertEquals(sem.getHotel(),H);
    }

    @Test
    void getDateFin() {
        Seminaire sem=new Seminaire("nom","lieu", LocalDate.now(),TypeEvenement.CONFERENCE,12.0,LocalDate.MAX);
        assertEquals(sem.getDateFin(),LocalDate.MAX);

    }

    @Test
    void setDateFin() {
        Seminaire sem=new Seminaire("nom","lieu", LocalDate.now(),TypeEvenement.CONFERENCE,12.0,LocalDate.MAX);
        sem.setDateFin(LocalDate.MIN);
        assertEquals(sem.getDateFin(),LocalDate.MIN);
    }
}