package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class EvenementTest {

    @Test
    void getNom() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        assertEquals(event.getNom(),"event");
    }

    @Test
    void getDate() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        assertEquals(event.getDate(),null);
    }

    @Test
    void getBudget() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        assertEquals(event.getBudget(),12.0);
    }

    @Test
    void getLieu() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        assertEquals(event.getLieu(),"lieu");
    }

    @Test
    void setNom() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        event.setNom("evenement");
        assertEquals(event.getNom(),"evenement");
    }

    @Test
    void setBudget() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        event.setBudget(15.0);
        assertEquals(event.getBudget(),15.0);
    }

    @Test
    void setDate() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        event.setDate(LocalDate.now());
        assertEquals(event.getDate(),LocalDate.now());
    }

    @Test
    void setLieu() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        event.setLieu("bar");
        assertEquals(event.getLieu(),"bar");
    }

    @Test
    void getType() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        assertEquals(event.getType(),TypeEvenement.CONFERENCE);
    }

    @Test
    void addMateriel() {
        Materiel mat=new Materiel("mat",12.0,5);
        ArrayList<Materiel> M = new ArrayList<>(Arrays.asList(mat));
        assertEquals(M.size(),1);

    }

    @Test
    void removeMateriel() {
        Materiel mat=new Materiel("mat",12.0,5);
        ArrayList<Materiel> M = new ArrayList<>(Arrays.asList(mat));
        M.remove(mat);
        assertEquals(M.size(),0);

    }

   @Test
    void getMateriels() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        Materiel mat=new Materiel("mat",12.0,5);
        event.addMateriel(mat);
        ArrayList<Materiel> M = new ArrayList<>(Arrays.asList(mat));
       assertEquals(M,event.getMateriels());
    }

    @Test
    void addNourriture() {
        Nourriture mat=new Nourriture("nom",12.0,4,true,true,true);
        ArrayList<Nourriture> nourritures = new ArrayList<>(Arrays.asList(mat));
        assertEquals(nourritures.size(),1);
    }

    @Test
    void removeNourriture() {
        Nourriture mat=new Nourriture("nom",12.0,4,true,true,true);
        ArrayList<Nourriture> nourritures = new ArrayList<>(Arrays.asList(mat));
        nourritures.remove(mat);
        assertEquals(nourritures.size(),0);
    }

    @Test
    void getMenu() {
        Nourriture mat=new Nourriture("nom",12.0,4,true,true,true);
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        event.addNourriture(mat);
        ArrayList<Nourriture> nourritures = new ArrayList<>(Arrays.asList(mat));
        assertEquals(nourritures,event.getMenu());
    }

    @Test
    void addInvite() {
        Invite INV=new Invite("nom","mail@mail");
        ArrayList<Invite> invites = new ArrayList<>(Arrays.asList(INV));
        assertEquals(invites.size(),1);
    }

    @Test
    void removeInvite() {
        Invite INV=new Invite("nom","mail@mail");
        ArrayList<Invite> invites = new ArrayList<>(Arrays.asList(INV));
        invites.remove(INV);
        assertEquals(invites.size(),0);
    }

    @Test
    void getInvites() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,12.0);
        Invite INV=new Invite("nom","mail@mail");
        event.addInvite(INV);
        ArrayList<Invite> invites = new ArrayList<>(Arrays.asList(INV));
        assertEquals(invites,event.getInvites());
    }

    @Test
    void getBudgetCourrant() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,40.0);
        Materiel mat=new Materiel("mat",12.0,5);
        ArrayList<Materiel> M = new ArrayList<>(Arrays.asList(mat));
        Nourriture mat2=new Nourriture("nom",12.0,4,true,true,true);
        ArrayList<Nourriture> nourritures = new ArrayList<>(Arrays.asList(mat2));
        assertEquals(event.getBudgetCourrant(),16.0);
    }

    @Test
    void dupliquer() {
        Evenement event=new Evenement("event","lieu",null,TypeEvenement.CONFERENCE,40.0);
        Evenement duplicatedEvnt=event.dupliquer();
        assertEquals("event(copie",duplicatedEvnt.getNom());
    }
}