package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InviteTest {

    @Test
    void getNom() {
        Invite inv=new Invite("nom","nom@nom");
        assertEquals(inv.getNom(),"nom");
    }

    @Test
    void setNom() {
        Invite inv=new Invite("nom","nom@nom");
        inv.setNom("invite");
        assertEquals(inv.getNom(),"invite");
    }

    @Test
    void getMail() {
        Invite inv=new Invite("nom","nom@nom");
        assertEquals(inv.getMail(),"nom@nom");
    }

    @Test
    void setMail() {
        Invite inv=new Invite("nom","nom@nom");
        inv.setMail("nom.prenom@gmail.com");
        assertEquals(inv.getMail(),"nom.prenom@gmail.com");
    }
}