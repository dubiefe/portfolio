package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MaterielTest {

    @Test
    void getNom() {
        Materiel mat=new Materiel("materiel",12.0,2);
        assertEquals(mat.getNom(),"materiel");
    }

    @Test
    void getPrix() {
        Materiel mat=new Materiel("materiel",12.0,2);
        assertEquals(mat.getPrix(),12.0);
    }

    @Test
    void getQuantite() {
        Materiel mat=new Materiel("materiel",12.0,2);
        assertEquals(mat.getQuantite(),2);
    }

    @Test
    void setNom() {
        Materiel mat=new Materiel("materiel",12.0,2);
        mat.setNom("mat");
        assertEquals(mat.getNom(),"mat");
    }

    @Test
    void setPrix() {
        Materiel mat=new Materiel("materiel",12.0,2);
        mat.setPrix(10.0);
        assertEquals(mat.getPrix(),10.0);
    }

    @Test
    void setQuantite() {
        Materiel mat=new Materiel("materiel",12.0,2);
        mat.setQuantite(3);
        assertEquals(mat.getQuantite(),3);
    }
}