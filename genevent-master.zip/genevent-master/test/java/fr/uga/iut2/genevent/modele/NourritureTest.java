package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NourritureTest {

    @Test
    void getNom() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        assertEquals(nourr.getNom(),"nourriture");
    }

    @Test
    void getPrix() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        assertEquals(nourr.getPrix(),20.0);
    }

    @Test
    void getPrixUnite() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        assertEquals(nourr.getPrixUnite(),10.0);
    }

    @Test
    void getQuantite() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        assertEquals(nourr.getQuantite(),2);
    }

    @Test
    void isVegan() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        assertEquals(nourr.isVegan(),true);
    }

    @Test
    void isVegetarien() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        assertEquals(nourr.isVegetarien(),true);
    }

    @Test
    void isAlcool() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        assertEquals(nourr.isAlcool(),true);
    }

    @Test
    void setNom() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        nourr.setNom("nom");
        assertEquals(nourr.getNom(),"nom");
    }

    @Test
    void setPrix() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        nourr.setPrix(12.0);
        assertEquals(nourr.getPrix(),12.0);
    }

    @Test
    void setQuantite() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        nourr.setQuantite(3);
        assertEquals(nourr.getQuantite(),0);
    }

    @Test
    void setVegan() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        nourr.setVegan(false);
        assertFalse(nourr.isVegan());
    }

    @Test
    void setVegetarien() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        nourr.setVegetarien(false);
        assertFalse(nourr.isVegetarien());
    }

    @Test
    void setAlcool() {
        Nourriture nourr=new Nourriture("nourriture",10.0,2,true,true,true);
        nourr.setAlcool(false);
        assertFalse(nourr.isAlcool());
    }
}