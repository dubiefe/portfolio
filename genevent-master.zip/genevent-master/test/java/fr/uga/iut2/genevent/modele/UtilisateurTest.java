package fr.uga.iut2.genevent.modele;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UtilisateurTest {

    @Test
    void getEmail() {
        Utilisateur uti=new Utilisateur("nom@nom","nom","personne");
        assertEquals(uti.getEmail(),"nom@nom");
    }

    @Test
    void getNom() {
        Utilisateur uti=new Utilisateur("nom@nom","nom","personne");
        assertEquals(uti.getNom(),"nom");
    }

    @Test
    void setNom() {
        Utilisateur uti=new Utilisateur("nom@nom","nom","personne");
        uti.setNom("utilisateur");
        assertEquals(uti.getNom(),"utilisateur");
    }

    @Test
    void getPrenom() {
        Utilisateur uti=new Utilisateur("nom@nom","nom","personne");
        assertEquals(uti.getPrenom(),"personne");
    }

    @Test
    void setPrenom() {
        Utilisateur uti=new Utilisateur("nom@nom","nom","personne");
        uti.setPrenom("utilisateur");
        assertEquals(uti.getPrenom(),"utilisateur");
    }

    @Test
    void ajouteEvenementAdministre() {
    }
}